INSERT INTO tcodes (tcode, module_name, description, function_details, page_url, status)
VALUES
('DASH','Dashboard','Shows KPI cards, system overview, and quick access summary.','KPIs, system overview, quick links, and operational snapshot.','modules/Dashboard/index.php','Active'),
('TASK','Task Manager','Manages validation tasks, assignments, due dates, and status.','Create/assign tasks, set due dates, track progress and validation status.','modules/TaskManager/index.php','Active'),
('QRMR','Quality Risk Management Report','Creates and monitors risk assessment records.','Risk assessment register, scoring, mitigations, and review schedule.','modules/QRMR/index.php','Active')
ON DUPLICATE KEY UPDATE status='Active';
