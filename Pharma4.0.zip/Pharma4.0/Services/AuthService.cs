using System.Collections.Concurrent;
using System.Text.RegularExpressions;
using Pharma40.Models;

namespace Pharma40.Services;

public sealed partial class AuthService(JsonDataStore store)
{
    private const string FullAccessAdminEmail = "carlolidres@gmail.com";
    private readonly ConcurrentDictionary<string, ResetCode> _resetCodes = new(StringComparer.OrdinalIgnoreCase);

    public User? GetUser(int id)
    {
        return store.Read().Users.FirstOrDefault(user => user.Id == id);
    }

    public (bool Success, string Message, User? User) Register(string fullName, string email, string password)
    {
        fullName = fullName.Trim();
        email = email.Trim().ToLowerInvariant();

        if (fullName.Length < 2)
        {
            return (false, "Please enter your full name.", null);
        }

        if (!EmailRegex().IsMatch(email))
        {
            return (false, "Please enter a valid email address.", null);
        }

        if (password.Length < 8)
        {
            return (false, "Password must be at least 8 characters.", null);
        }

        var data = store.Read();
        if (data.Users.Any(user => user.Email.Equals(email, StringComparison.OrdinalIgnoreCase)))
        {
            return (false, "Email already registered.", null);
        }

        var usernameBase = email.Split('@')[0].Replace(".", "", StringComparison.OrdinalIgnoreCase);
        var username = string.IsNullOrWhiteSpace(usernameBase) ? $"user{data.NextUserId}" : usernameBase;
        var uniqueUsername = username;
        var counter = 1;
        while (data.Users.Any(user => user.Username.Equals(uniqueUsername, StringComparison.OrdinalIgnoreCase)))
        {
            uniqueUsername = $"{username}{counter++}";
        }

        var now = DateTime.UtcNow;
        var user = new User
        {
            Id = data.NextUserId++,
            UserCode = BuildUserCode(now, data.NextUserId - 1),
            FullName = fullName,
            Username = uniqueUsername,
            Email = email,
            PasswordHash = PasswordHasher.Hash(password),
            Role = IsFullAccessAdmin(email) ? "Administrator" : "User",
            Status = "Active",
            CreatedAt = now,
            UpdatedAt = now
        };

        data.Users.Add(user);
        store.Write(data);

        return (true, "Account created. You can now sign in.", user);
    }

    public (bool Success, string Message, User? User) Login(string email, string password)
    {
        email = email.Trim().ToLowerInvariant();
        var data = store.Read();
        var user = data.Users.FirstOrDefault(item => item.Email.Equals(email, StringComparison.OrdinalIgnoreCase));
        if (user is null || !PasswordHasher.Verify(password, user.PasswordHash))
        {
            return (false, "Invalid email or password.", null);
        }

        var changed = false;
        if (string.IsNullOrWhiteSpace(user.UserCode))
        {
            user.UserCode = BuildUserCode(user.CreatedAt, user.Id);
            changed = true;
        }

        if (IsFullAccessAdmin(user.Email) && user.Role != "Administrator")
        {
            user.Role = "Administrator";
            user.UpdatedAt = DateTime.UtcNow;
            changed = true;
        }

        if (changed)
        {
            store.Write(data);
        }

        if (!user.Status.Equals("Active", StringComparison.OrdinalIgnoreCase))
        {
            return (false, "Your account is not active. Please contact an administrator.", null);
        }

        return (true, "Login successful.", user);
    }

    public (bool Success, string Message, string? Code) SendResetCode(string email)
    {
        email = email.Trim().ToLowerInvariant();
        var user = store.Read().Users.FirstOrDefault(item => item.Email.Equals(email, StringComparison.OrdinalIgnoreCase));
        if (user is null)
        {
            return (false, "Email not registered.", null);
        }

        var code = Random.Shared.Next(100000, 999999).ToString();
        _resetCodes[email] = new ResetCode(code, DateTime.UtcNow.AddMinutes(10));

        return (true, "Reset code generated. For this local build, use the displayed code.", code);
    }

    public (bool Success, string Message) ResetPassword(string email, string code, string newPassword)
    {
        email = email.Trim().ToLowerInvariant();
        if (!_resetCodes.TryGetValue(email, out var resetCode) || resetCode.ExpiresAt < DateTime.UtcNow || resetCode.Code != code.Trim())
        {
            return (false, "Invalid or expired reset code.");
        }

        if (newPassword.Length < 8)
        {
            return (false, "Password must be at least 8 characters.");
        }

        var data = store.Read();
        var user = data.Users.FirstOrDefault(item => item.Email.Equals(email, StringComparison.OrdinalIgnoreCase));
        if (user is null)
        {
            return (false, "User not found.");
        }

        user.PasswordHash = PasswordHasher.Hash(newPassword);
        user.UpdatedAt = DateTime.UtcNow;
        store.Write(data);
        _resetCodes.TryRemove(email, out _);

        return (true, "Password reset successfully. Please sign in.");
    }

    [GeneratedRegex(@"^[^\s@]+@[^\s@]+\.[^\s@]+$")]
    private static partial Regex EmailRegex();

    private static bool IsFullAccessAdmin(string email)
    {
        return email.Equals(FullAccessAdminEmail, StringComparison.OrdinalIgnoreCase);
    }

    private static string BuildUserCode(DateTime date, int id)
    {
        return $"USR-{date.Year}-{id:0000}";
    }

    private sealed record ResetCode(string Code, DateTime ExpiresAt);
}
