using System.Text.Json;
using Pharma40.Models;

namespace Pharma40.Services;

public sealed class JsonDataStore
{
    private readonly string _filePath;
    private readonly object _sync = new();
    private readonly JsonSerializerOptions _options = new() { WriteIndented = true };

    public JsonDataStore(IWebHostEnvironment environment)
    {
        var dataDirectory = Path.Combine(environment.ContentRootPath, "App_Data");
        Directory.CreateDirectory(dataDirectory);
        _filePath = Path.Combine(dataDirectory, "app-data.json");
        EnsureCreated();
    }

    public AppData Read()
    {
        lock (_sync)
        {
            EnsureCreated();
            var json = File.ReadAllText(_filePath);
            var data = JsonSerializer.Deserialize<AppData>(json, _options) ?? SeedData();
            if (EnsureRequiredTCodes(data))
            {
                File.WriteAllText(_filePath, JsonSerializer.Serialize(data, _options));
            }

            return data;
        }
    }

    public void Write(AppData data)
    {
        lock (_sync)
        {
            File.WriteAllText(_filePath, JsonSerializer.Serialize(data, _options));
        }
    }

    private void EnsureCreated()
    {
        if (File.Exists(_filePath) && new FileInfo(_filePath).Length > 0)
        {
            return;
        }

        Write(SeedData());
    }

    private static AppData SeedData()
    {
        var now = DateTime.UtcNow;
        return new AppData
        {
            TCodes =
            [
                NewTCode(1, "DASH", "Dashboard", "Shows KPI cards, system overview, and quick access summary.", "Validation performance command center.", "modules/Dashboard/index.php", now),
                NewTCode(2, "TASK", "Task Manager", "Manages validation tasks, assignments, due dates, and status.", "Create, assign, monitor, and close validation tasks.", "modules/TaskManager/index.php", now),
                NewTCode(3, "MVW", "Month View", "Displays monthly calendar activities and validation schedules.", "Monthly validation activity planning view.", "#", now),
                NewTCode(4, "TLN", "Timeline View", "Shows Gantt-style validation timelines and project milestones.", "Timeline and milestone tracking for validation work.", "#", now),
                NewTCode(5, "WRK", "Workload Monitoring", "Monitors personnel workload, pending tasks, and completion rate.", "Workload and capacity visibility.", "#", now),
                NewTCode(6, "CNF", "Change Notification", "Tracks change control notifications and validation impact.", "Change notification and impact assessment workflow.", "modules/CNF/index.php", now),
                NewTCode(7, "QRMR", "Quality Risk Management Report", "Creates and monitors risk assessment records.", "Risk assessment records, matrix, and mitigation tracking.", "modules/QRMR/index.php", now),
                NewTCode(8, "APR", "Annual Product Review", "Tracks APR/APQR preparation, review status, and commitments.", "Annual review preparation and commitment tracking.", "modules/APR/index.php", now),
                NewTCode(9, "VMP", "Validation Master Plan", "Manages validation plans, protocols, and reports.", "Validation plan, protocol, and report oversight.", "#", now),
                NewTCode(10, "ADMIN", "Administration", "User management, role access, configuration, and database controls.", "Administrative configuration and role access.", "modules/Admin/index.php", now),
                NewTCode(11, "VRMS", "Document Management and Routing System", "Registers controlled documents, monitors routing, and captures eSignatures.", "Document routing monitoring, eDMS metadata, revision control, attachments, eSignature workflow, and audit trail.", "/Documents", now)
            ]
        };
    }

    private static bool EnsureRequiredTCodes(AppData data)
    {
        if (data.TCodes.Any(item => item.Code.Equals("VRMS", StringComparison.OrdinalIgnoreCase)))
        {
            return false;
        }

        var nextId = data.TCodes.Count == 0 ? 1 : data.TCodes.Max(item => item.Id) + 1;
        data.TCodes.Add(NewTCode(
            nextId,
            "VRMS",
            "Document Management and Routing System",
            "Registers controlled documents, monitors routing, and captures eSignatures.",
            "Document routing monitoring, eDMS metadata, revision control, attachments, eSignature workflow, and audit trail.",
            "/Documents",
            DateTime.UtcNow));
        return true;
    }

    private static TCode NewTCode(int id, string code, string name, string description, string details, string url, DateTime createdAt)
    {
        return new TCode
        {
            Id = id,
            Code = code,
            ModuleName = name,
            Description = description,
            FunctionDetails = details,
            PageUrl = url,
            CreatedAt = createdAt
        };
    }
}
