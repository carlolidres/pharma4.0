using Pharma40.Models;

namespace Pharma40.Services;

public sealed class TCodeService(JsonDataStore store)
{
    public IReadOnlyList<TCode> GetAll()
    {
        return store.Read().TCodes
            .OrderBy(item => item.Code)
            .ToList();
    }

    public TCode? Find(string code)
    {
        return store.Read().TCodes.FirstOrDefault(item =>
            item.Code.Equals(code.Trim(), StringComparison.OrdinalIgnoreCase) &&
            item.Status.Equals("Active", StringComparison.OrdinalIgnoreCase));
    }
}
