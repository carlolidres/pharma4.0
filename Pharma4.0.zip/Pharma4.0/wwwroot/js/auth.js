const authContainer = document.getElementById("authContainer");
const signUpButton = document.getElementById("signUp");
const signInButton = document.getElementById("signIn");
const signupForm = document.getElementById("signupForm");
const loginForm = document.getElementById("loginForm");
const forgotPasswordLink = document.getElementById("forgotPasswordLink");
const emailRequestModal = document.getElementById("emailRequestModal");
const otpEntryModal = document.getElementById("otpEntryModal");
const sendOtpButton = document.getElementById("sendOtpButton");
const resetPasswordButton = document.getElementById("resetPasswordButton");

window.PharmaTheme?.apply(window.PharmaTheme.current());

signUpButton?.addEventListener("click", () => {
    authContainer.classList.add("right-panel-active");
    clearMessages();
});

signInButton?.addEventListener("click", () => {
    authContainer.classList.remove("right-panel-active");
    clearMessages();
});

signupForm?.addEventListener("submit", async (event) => {
    event.preventDefault();
    const message = document.getElementById("signupMessage");
    const payload = new URLSearchParams(new FormData(signupForm));
    showMessage(message, "neutral", "Creating account...");

    const response = await postForm(window.AUTH_ENDPOINTS.register, payload);
    showMessage(message, response.success ? "success" : "error", response.message || "Unexpected server response.");

    if (response.success) {
        signupForm.reset();
        setTimeout(() => authContainer.classList.remove("right-panel-active"), 850);
    }
});

loginForm?.addEventListener("submit", async (event) => {
    event.preventDefault();
    const message = document.getElementById("loginMessage");
    const payload = new URLSearchParams(new FormData(loginForm));
    showMessage(message, "neutral", "Signing in...");

    const response = await postForm(window.AUTH_ENDPOINTS.login, payload);
    showMessage(message, response.success ? "success" : "error", response.message || "Unexpected server response.");

    if (response.success && response.redirectUrl) {
        window.location.href = response.redirectUrl;
    }
});

forgotPasswordLink?.addEventListener("click", (event) => {
    event.preventDefault();
    emailRequestModal.classList.add("open");
});

sendOtpButton?.addEventListener("click", async () => {
    const message = document.getElementById("forgotEmailMessage");
    const email = document.getElementById("forgotEmail").value.trim();
    showMessage(message, "neutral", "Generating reset code...");

    const response = await postForm(window.AUTH_ENDPOINTS.sendCode, new URLSearchParams({ email }));
    const displayMessage = response.code ? `${response.message} Code: ${response.code}` : response.message;
    showMessage(message, response.success ? "success" : "error", displayMessage || "Unexpected server response.");

    if (response.success) {
        setTimeout(() => {
            emailRequestModal.classList.remove("open");
            otpEntryModal.classList.add("open");
            document.getElementById("otpInput").focus();
        }, 900);
    }
});

resetPasswordButton?.addEventListener("click", async () => {
    const message = document.getElementById("otpMessage");
    const email = document.getElementById("forgotEmail").value.trim();
    const code = document.getElementById("otpInput").value.trim();
    const newPassword = document.getElementById("newPassword").value;
    showMessage(message, "neutral", "Resetting password...");

    const response = await postForm(window.AUTH_ENDPOINTS.resetPassword, new URLSearchParams({ email, code, newPassword }));
    showMessage(message, response.success ? "success" : "error", response.message || "Unexpected server response.");

    if (response.success) {
        setTimeout(() => {
            otpEntryModal.classList.remove("open");
            authContainer.classList.remove("right-panel-active");
        }, 900);
    }
});

document.querySelectorAll(".close-button").forEach((button) => {
    button.addEventListener("click", () => {
        document.getElementById(button.dataset.modal)?.classList.remove("open");
    });
});

async function postForm(url, body) {
    try {
        const response = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body
        });
        return await response.json();
    } catch (error) {
        return { success: false, message: "Unexpected server response. Please refresh the page and try again." };
    }
}

function showMessage(element, type, message) {
    element.textContent = message;
    element.className = `message ${type}`;
}

function clearMessages() {
    document.querySelectorAll(".message").forEach((element) => {
        element.textContent = "";
        element.className = "message";
    });
}
