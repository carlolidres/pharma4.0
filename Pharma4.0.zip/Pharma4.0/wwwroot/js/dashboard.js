const appState = {
    collapsed: localStorage.getItem("pharma40-sidebar") === "collapsed",
    sidebarMode: localStorage.getItem("pharma40-sidebar-mode") || "click",
    profileOpen: false,
    notificationOpen: false,
    theme: window.PharmaTheme?.current() || "light",
    filter: "",
    modal: null,
    tcodes: [],
    notifications: loadNotifications(),
    profile: loadProfile()
};

const profileFields = [
    ["companyName", "Company Name"],
    ["departmentUnit", "Department / Unit"],
    ["address1", "Address Line 1"],
    ["address2", "Address Line 2"],
    ["address3", "Address Line 3"],
    ["city", "City / Municipality"],
    ["state", "State / Province / Region"],
    ["postalCode", "Postal / ZIP Code"],
    ["country", "Country"],
    ["positionTitle", "Position Title"],
    ["rank", "Rank / Position Level"]
];

const rankOptions = [
    "C-Suite",
    "VP",
    "Director",
    "Manager",
    "Supervisor",
    "Rank and File",
    "Trainee / Internship",
    "3rd Party"
];

const navItems = [
    ["Launch Pad", "LP", "layout-dashboard"],
    ["Dashboard", "DS", "gauge"],
    ["Audit Trail", "AU", "history"],
    ["Administration", "AD", "settings"]
];

document.addEventListener("DOMContentLoaded", async () => {
    appState.theme = window.PharmaTheme?.apply(appState.theme) || appState.theme;
    render();
    await loadTcodes();
});

async function loadTcodes() {
    const response = await fetch(window.PHARMA40_ENDPOINTS.list);
    const result = await response.json();
    appState.tcodes = result.items || [];
    render();
}

function render() {
    const root = document.getElementById("dashboardRoot");
    root.innerHTML = dashboardTemplate();
    wireEvents();
    hydrateIcons();
}

function dashboardTemplate() {
    const filtered = filteredTcodes();
    const sidebarCollapsed = appState.sidebarMode === "hover" || appState.collapsed;
    return `
        <div class="app-shell sidebar-mode-${appState.sidebarMode} ${sidebarCollapsed ? "sidebar-collapsed" : ""}">
            ${sidebarTemplate()}
            <main class="main-workspace">
                ${topbarTemplate()}
                <section class="content">
                    ${heroTemplate()}
                    <div class="dashboard-grid">
                        ${kpiTemplate()}
                        <section class="content-grid">
                            ${directoryTemplate(filtered)}
                            ${modulesTemplate(filtered)}
                        </section>
                    </div>
                </section>
            </main>
            ${modalTemplate()}
        </div>
    `;
}

function sidebarTemplate() {
    return `
        <aside class="sidebar">
            <div class="brand-row">
                <div class="brand-mark">P4</div>
                <div class="brand-copy">
                    <strong>Pharma 4.0</strong>
                    <span>Validation Management</span>
                </div>
            </div>
            <nav class="side-nav" aria-label="Primary navigation">
                ${navItems.map(([label, short, icon], index) => `
                    <button class="nav-item ${index === 0 ? "active" : ""}" type="button" title="${label}">
                        <span class="nav-icon"><i data-lucide="${icon}"></i></span>
                        <span class="nav-label">${label}</span>
                    </button>
                `).join("")}
            </nav>
            ${appState.sidebarMode === "click" ? `<div class="sidebar-toggle-wrap">
                <button class="sidebar-toggle" id="sidebarToggle" type="button" aria-label="Toggle sidebar" aria-expanded="${!appState.collapsed}">
                    <i data-lucide="${appState.collapsed ? "panel-right-open" : "panel-left-close"}"></i>
                    <span class="toggle-label">Collapse</span>
                </button>
            </div>` : ""}
        </aside>
    `;
}

function topbarTemplate() {
    return `
        <header class="topbar">
            <div class="topbar-title">
                <strong>Validation Launch Pad</strong>
                <span>GMP/GxP enterprise workspace</span>
            </div>
            <div class="topbar-actions">
                ${notificationBellTemplate()}
                <button class="profile-button" id="profileButton" type="button">
                    ${avatarTemplate("avatar")}
                    <span class="profile-copy">
                        <strong>${escapeHtml(window.PHARMA40_USER.fullName)}</strong>
                        <span>${escapeHtml(window.PHARMA40_USER.role)}</span>
                    </span>
                    <i data-lucide="chevron-down"></i>
                </button>
                ${notificationPanelTemplate()}
                ${profileMenuTemplate()}
            </div>
        </header>
    `;
}

function notificationBellTemplate() {
    const unread = appState.notifications.filter(item => !item.read).length;
    return `
        <button class="notification-button" id="notificationButton" type="button" aria-label="Notifications" aria-expanded="${appState.notificationOpen}">
            <i data-lucide="bell"></i>
            ${unread ? `<span class="notification-count">${Math.min(unread, 9)}</span>` : ""}
        </button>
    `;
}

function notificationPanelTemplate() {
    const items = appState.notifications.slice(0, 8);
    return `
        <div class="notification-panel ${appState.notificationOpen ? "open" : ""}" id="notificationPanel">
            <div class="notification-head">
                <div>
                    <strong>Notifications</strong>
                    <span>${items.length ? "Recent system activity" : "No recent activity"}</span>
                </div>
                <button class="btn-ghost" id="markNotificationsRead" type="button">Mark read</button>
            </div>
            <div class="notification-list">
                ${items.map(notificationItemTemplate).join("") || `<div class="empty-state">No notifications yet.</div>`}
            </div>
        </div>
    `;
}

function notificationItemTemplate(item) {
    const content = `
        <span class="notification-dot"></span>
        <span>
            <span class="notification-title">${escapeHtml(item.title)}<span class="notification-time">${escapeHtml(item.time)}</span></span>
            <span class="notification-copy">${escapeHtml(item.message)}</span>
        </span>
    `;
    if (item.url) {
        return `<a class="notification-item ${item.read ? "read" : ""}" href="${escapeAttribute(item.url)}" target="_blank" rel="noopener noreferrer">${content}</a>`;
    }
    return `<div class="notification-item ${item.read ? "read" : ""}">${content}</div>`;
}

function profileMenuTemplate() {
    return `
        <div class="profile-menu ${appState.profileOpen ? "open" : ""}" id="profileMenu">
            <div class="profile-summary">
                ${avatarTemplate("avatar profile-avatar")}
                <div class="profile-copy">
                    <strong>${escapeHtml(window.PHARMA40_USER.fullName)}</strong>
                    <span>${escapeHtml(window.PHARMA40_USER.email)}</span>
                    <span>${escapeHtml(window.PHARMA40_USER.userId || "")}</span>
                </div>
            </div>
            <div class="profile-section-title">ID Photo</div>
            <div class="photo-uploader" id="photoDropZone">
                ${avatarTemplate("photo-preview")}
                <div class="photo-copy">
                    <strong>Profile / ID Photo</strong>
                    <span>JPG, JPEG, PNG, or WEBP. Images are resized for performance.</span>
                    <div class="photo-actions">
                        <label class="btn-ghost" for="photoInput"><i data-lucide="upload"></i> Upload</label>
                        <button class="btn-ghost" id="removePhotoButton" type="button"><i data-lucide="trash-2"></i> Remove</button>
                    </div>
                    <input id="photoInput" type="file" accept="image/jpeg,image/jpg,image/png,image/webp" hidden />
                    <p class="photo-message" id="photoMessage"></p>
                </div>
            </div>
            <div class="profile-section-title">Appearance</div>
            <div class="field">
                <label for="themeSelect">Theme</label>
                <select id="themeSelect">
                    ${themeOption("light", "Light")}
                    ${themeOption("dark", "Dark")}
                    ${themeOption("night", "Night")}
                </select>
            </div>
            <div class="field">
                <label for="sidebarModeSelect">Sidebar behavior</label>
                <select id="sidebarModeSelect">
                    ${sidebarModeOption("hover", "Hover Mode")}
                    ${sidebarModeOption("click", "Click Mode")}
                </select>
                <span class="field-help">${appState.sidebarMode === "hover"
                    ? "Expands on hover and collapses when the cursor leaves."
                    : "Expands and collapses only when you click the sidebar control."}</span>
            </div>
            <div class="profile-section-title">Company Profile</div>
            <div class="profile-grid">
                <div class="field">
                    <label>User ID</label>
                    <input value="${escapeAttribute(window.PHARMA40_USER.userId || "")}" readonly />
                </div>
                ${profileFields.map(([key, label]) => profileFieldTemplate(key, label)).join("")}
                <div class="field full">
                    <label>Formatted Address</label>
                    <textarea readonly>${formattedAddress()}</textarea>
                </div>
            </div>
            <div class="profile-actions">
                <button class="btn-primary" id="saveProfileButton" type="button"><i data-lucide="save"></i> Save Profile</button>
                <a class="logout-link" href="/Logout">Logout</a>
            </div>
        </div>
    `;
}

function heroTemplate() {
    return `
        <section class="hero-panel">
            <div>
                <p class="eyebrow">GxP command center</p>
                <h1 class="hero-title">Launch Pad</h1>
                <p class="hero-copy">Search and launch validation modules using controlled transaction codes.</p>
            </div>
            <div class="command-box">
                <input id="heroTcodeInput" type="text" placeholder="Type T-code" autocomplete="off" />
                <button id="heroLaunchButton" class="btn-primary" type="button"><i data-lucide="send"></i> Launch</button>
            </div>
        </section>
    `;
}

function kpiTemplate() {
    const today = new Date().toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
    const activeCount = appState.tcodes.filter(item => item.status === "Active").length || 10;
    return `
        <section class="kpi-grid" aria-label="Launch pad summary">
            ${kpiCard("blue", "Active Modules", activeCount, "Transaction directory", "boxes", "modules")}
            ${kpiCard("purple", "Role", window.PHARMA40_USER.role, "Access profile", "shield-check", "role")}
            ${kpiCard("green", "Status", window.PHARMA40_USER.status || "Active", "Account state", "check-circle-2", "status")}
            ${kpiCard("amber", "Today", today, "Local workspace time", "calendar-days", "today")}
        </section>
    `;
}

function kpiCard(color, label, value, help, icon, type) {
    return `
        <article class="kpi-card ${color} ${type}">
            <div>
                <span class="kpi-label">${label}</span>
                <strong class="kpi-value" title="${escapeHtml(String(value))}">${escapeHtml(String(value))}</strong>
                <p class="kpi-help">${help}</p>
            </div>
            <span class="kpi-icon"><i data-lucide="${icon}"></i></span>
        </article>
    `;
}

function directoryTemplate(items) {
    return `
        <article class="panel">
            <div class="panel-header">
                <div>
                    <h2 class="section-title">Transaction Directory</h2>
                    <p class="section-copy">Find modules by code, name, or description.</p>
                </div>
                <div class="filter-box">
                    <input id="directoryFilter" type="search" value="${escapeAttribute(appState.filter)}" placeholder="Filter directory..." />
                </div>
            </div>
            <div class="directory-list">
                ${items.map(directoryItemTemplate).join("") || emptyState("No matching transactions.")}
            </div>
        </article>
    `;
}

function directoryItemTemplate(item) {
    return `
        <div class="directory-item" data-code="${item.code}">
            <span class="code-badge">${escapeHtml(item.code)}</span>
            <div class="item-body">
                <h3 class="item-title">${escapeHtml(item.moduleName)}</h3>
                <p class="item-copy">${escapeHtml(item.description)}</p>
            </div>
            <span class="badge active">${escapeHtml(item.status)}</span>
        </div>
    `;
}

function modulesTemplate(items) {
    return `
        <article class="panel">
            <div class="panel-header no-filter">
                <div>
                    <h2 class="section-title">Modules</h2>
                    <p class="section-copy">Click a module card to launch the placeholder view.</p>
                </div>
            </div>
            <div class="module-grid">
                ${items.map(moduleTileTemplate).join("") || emptyState("No modules to show.")}
            </div>
        </article>
    `;
}

function moduleTileTemplate(item) {
    return `
        <div class="module-tile" data-code="${item.code}">
            <div>
                <div class="tile-top">
                    <span class="code-badge">${escapeHtml(item.code)}</span>
                    <span class="badge active">${escapeHtml(item.status)}</span>
                </div>
                <h3 class="module-title">${escapeHtml(item.moduleName)}</h3>
                <p class="module-copy">${escapeHtml(item.functionDetails || item.description)}</p>
            </div>
        </div>
    `;
}

function modalTemplate() {
    if (!appState.modal) {
        return "";
    }

    const item = appState.modal;
    return `
        <div class="module-modal open" id="moduleModal">
            <div class="module-dialog">
                <button class="dialog-close" id="modalClose" type="button" aria-label="Close"><i data-lucide="x"></i></button>
                <p class="eyebrow">${escapeHtml(item.code)}</p>
                <h2>${escapeHtml(item.moduleName)}</h2>
                <p>${escapeHtml(item.functionDetails || item.description)}</p>
                <div class="dialog-footer">
                    <span class="badge active">${escapeHtml(item.status || "Active")}</span>
            <a href="${escapeAttribute(normalizeLaunchUrl(item.pageUrl || "#"))}" target="_blank" rel="noopener noreferrer" class="btn-primary"><i data-lucide="external-link"></i> Open Module</a>
                </div>
            </div>
        </div>
    `;
}

function wireEvents() {
    const shell = document.querySelector(".app-shell");
    const sidebar = document.querySelector(".sidebar");

    sidebar?.addEventListener("mouseenter", () => {
        if (appState.sidebarMode === "hover") {
            shell?.classList.add("sidebar-hovered");
        }
    });

    sidebar?.addEventListener("mouseleave", () => {
        if (appState.sidebarMode === "hover") {
            shell?.classList.remove("sidebar-hovered");
        }
    });

    document.getElementById("sidebarToggle")?.addEventListener("click", () => {
        if (appState.sidebarMode !== "click") {
            return;
        }
        appState.collapsed = !appState.collapsed;
        localStorage.setItem("pharma40-sidebar", appState.collapsed ? "collapsed" : "expanded");
        shell?.classList.toggle("sidebar-collapsed", appState.collapsed);
        shell?.classList.remove("sidebar-hovered");
        const iconName = appState.collapsed ? "panel-right-open" : "panel-left-close";
        const toggle = document.getElementById("sidebarToggle");
        if (toggle) {
            toggle.setAttribute("aria-expanded", String(!appState.collapsed));
            toggle.innerHTML = `<i data-lucide="${iconName}"></i><span class="toggle-label">Collapse</span>`;
            hydrateIcons();
        }
    });

    document.getElementById("profileButton")?.addEventListener("click", (event) => {
        event.stopPropagation();
        appState.profileOpen = !appState.profileOpen;
        appState.notificationOpen = false;
        render();
    });

    document.getElementById("notificationButton")?.addEventListener("click", (event) => {
        event.stopPropagation();
        appState.notificationOpen = !appState.notificationOpen;
        appState.profileOpen = false;
        if (appState.notificationOpen) {
            appState.notifications = appState.notifications.map(item => ({ ...item, read: true }));
            saveNotifications();
        }
        render();
    });

    document.getElementById("profileMenu")?.addEventListener("click", (event) => event.stopPropagation());
    document.getElementById("notificationPanel")?.addEventListener("click", (event) => event.stopPropagation());
    document.getElementById("markNotificationsRead")?.addEventListener("click", () => {
        appState.notifications = appState.notifications.map(item => ({ ...item, read: true }));
        saveNotifications();
        appState.notificationOpen = true;
        render();
    });
    document.addEventListener("click", closeProfileOnce, { once: true });

    document.getElementById("themeSelect")?.addEventListener("change", (event) => {
        appState.theme = window.PharmaTheme?.apply(event.target.value) || event.target.value;
        appState.profileOpen = true;
        render();
    });

    document.getElementById("sidebarModeSelect")?.addEventListener("change", (event) => {
        appState.sidebarMode = event.target.value === "hover" ? "hover" : "click";
        localStorage.setItem("pharma40-sidebar-mode", appState.sidebarMode);
        if (appState.sidebarMode === "hover") {
            appState.collapsed = true;
            localStorage.setItem("pharma40-sidebar", "collapsed");
        }
        appState.profileOpen = true;
        render();
    });

    document.querySelectorAll("[data-profile-field]").forEach((element) => {
        element.addEventListener("input", (event) => {
            appState.profile[event.target.dataset.profileField] = event.target.value;
        });
    });

    document.getElementById("saveProfileButton")?.addEventListener("click", () => {
        if (!validateProfile()) {
            appState.profileOpen = true;
            render();
            return;
        }
        localStorage.setItem("pharma40-profile", JSON.stringify(appState.profile));
        appState.profileOpen = false;
        render();
    });

    wirePhotoUpload();

    const heroInput = document.getElementById("heroTcodeInput");
    document.getElementById("heroLaunchButton")?.addEventListener("click", () => launchTcode(heroInput.value));
    heroInput?.addEventListener("keydown", (event) => {
        if (event.key === "Enter") {
            launchTcode(heroInput.value);
        }
    });

    document.getElementById("directoryFilter")?.addEventListener("input", (event) => {
        appState.filter = event.target.value;
        updateFilteredLists();
    });

    document.querySelectorAll("[data-code]").forEach((element) => {
        element.addEventListener("click", () => launchTcode(element.dataset.code));
    });

    document.getElementById("modalClose")?.addEventListener("click", () => {
        appState.modal = null;
        render();
    });

    document.getElementById("moduleModal")?.addEventListener("click", (event) => {
        if (event.target.id === "moduleModal") {
            appState.modal = null;
            render();
        }
    });
}

function updateFilteredLists() {
    const filtered = filteredTcodes();
    const directory = document.querySelector(".directory-list");
    const modules = document.querySelector(".module-grid");
    if (directory) {
        directory.innerHTML = filtered.map(directoryItemTemplate).join("") || emptyState("No matching transactions.");
    }
    if (modules) {
        modules.innerHTML = filtered.map(moduleTileTemplate).join("") || emptyState("No modules to show.");
    }
    document.querySelectorAll("[data-code]").forEach((element) => {
        element.addEventListener("click", () => launchTcode(element.dataset.code));
    });
    hydrateIcons();
}

function closeProfileOnce() {
    if (appState.profileOpen || appState.notificationOpen) {
        appState.profileOpen = false;
        appState.notificationOpen = false;
        render();
    }
}

async function launchTcode(code) {
    const tcode = (code || "").trim().toUpperCase();
    if (!tcode) {
        pushNotification("T-Code required", "Please type or select a transaction code before launching.", "warning");
        return;
    }

    const response = await fetch(`${window.PHARMA40_ENDPOINTS.launch}&tcode=${encodeURIComponent(tcode)}`);
    const result = await response.json();
    if (result.success && result.item?.pageUrl && result.item.pageUrl !== "#") {
        openTcodeTarget(result.item.pageUrl, result.item);
        return;
    }

    pushNotification("T-Code not found", result.message || `${tcode} is not registered.`, "error");
}

function openTcodeTarget(pageUrl, item = {}) {
    const target = normalizeLaunchUrl(pageUrl);
    const opened = window.open(target, "_blank", "noopener,noreferrer");
    if (!opened) {
        pushNotification("New tab blocked", "Your browser blocked the module tab. Use this notification link after allowing popups.", "warning", target);
        return;
    }
    pushNotification("Module opened", `${item.code || "T-Code"} opened in a separate tab.`, "success", target);
}

function normalizeLaunchUrl(pageUrl) {
    const raw = String(pageUrl || "#").trim();
    if (!raw || raw === "#") return "#";
    try {
        return new URL(raw, window.location.origin).href;
    } catch {
        return "#";
    }
}

function filteredTcodes() {
    const query = appState.filter.trim().toLowerCase();
    if (!query) {
        return appState.tcodes;
    }

    return appState.tcodes.filter((item) =>
        item.code.toLowerCase().includes(query) ||
        item.moduleName.toLowerCase().includes(query) ||
        item.description.toLowerCase().includes(query)
    );
}

function profileFieldTemplate(key, label) {
    const value = appState.profile[key] || "";
    if (key === "rank") {
        return `
            <div class="field ${key === "rank" ? "full" : ""}">
                <label>${label}</label>
                <select data-profile-field="${key}" required>
                    <option value="">Select level</option>
                    ${rankOptions.map(option => `<option value="${escapeAttribute(option)}" ${value === option ? "selected" : ""}>${escapeHtml(option)}</option>`).join("")}
                </select>
            </div>
        `;
    }

    return `
        <div class="field ${["companyName", "departmentUnit"].includes(key) ? "full" : ""}">
            <label>${label}</label>
            <input data-profile-field="${key}" value="${escapeAttribute(value)}" placeholder="${label}" ${isRequiredProfileField(key) ? "required" : ""} />
        </div>
    `;
}

function formattedAddress() {
    const p = appState.profile;
    return [
        p.companyName,
        p.departmentUnit,
        p.address1,
        p.address2,
        p.address3,
        [p.city, [p.state, p.postalCode].filter(Boolean).join(" ")].filter(Boolean).join(", "),
        p.country
    ].filter(Boolean).join("\n");
}

function validateProfile() {
    const missing = profileFields
        .filter(([key]) => isRequiredProfileField(key) && !String(appState.profile[key] || "").trim())
        .map(([, label]) => label);

    if (!missing.length) {
        return true;
    }

    alert(`Please complete required profile fields:\n\n${missing.join("\n")}`);
    return false;
}

function isRequiredProfileField(key) {
    return [
        "companyName",
        "address1",
        "address2",
        "address3",
        "city",
        "state",
        "postalCode",
        "country",
        "positionTitle",
        "rank"
    ].includes(key);
}

function avatarTemplate(className) {
    const image = appState.profile.photo;
    if (image) {
        return `<span class="${className}"><img src="${escapeAttribute(image)}" alt="Profile photo" /></span>`;
    }

    return `<span class="${className}">${window.PHARMA40_USER.initials}</span>`;
}

function wirePhotoUpload() {
    const input = document.getElementById("photoInput");
    const dropZone = document.getElementById("photoDropZone");
    const removeButton = document.getElementById("removePhotoButton");

    input?.addEventListener("change", async (event) => {
        const file = event.target.files?.[0];
        if (file) {
            await processPhoto(file);
        }
    });

    removeButton?.addEventListener("click", () => {
        delete appState.profile.photo;
        localStorage.setItem("pharma40-profile", JSON.stringify(appState.profile));
        appState.profileOpen = true;
        render();
    });

    dropZone?.addEventListener("dragover", (event) => {
        event.preventDefault();
        dropZone.classList.add("drag-over");
    });

    dropZone?.addEventListener("dragleave", () => dropZone.classList.remove("drag-over"));

    dropZone?.addEventListener("drop", async (event) => {
        event.preventDefault();
        dropZone.classList.remove("drag-over");
        const file = event.dataTransfer?.files?.[0];
        if (file) {
            await processPhoto(file);
        }
    });
}

async function processPhoto(file) {
    const message = document.getElementById("photoMessage");
    const allowedTypes = ["image/jpeg", "image/jpg", "image/png", "image/webp"];
    if (!allowedTypes.includes(file.type)) {
        if (message) message.textContent = "Unsupported image type. Use JPG, JPEG, PNG, or WEBP.";
        return;
    }

    if (file.size > 5 * 1024 * 1024) {
        if (message) message.textContent = "Image is too large. Maximum file size is 5 MB.";
        return;
    }

    const resized = await resizeImage(file, 360, 0.82);
    appState.profile.photo = resized;
    localStorage.setItem("pharma40-profile", JSON.stringify(appState.profile));
    appState.profileOpen = true;
    render();
}

function resizeImage(file, maxSize, quality) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onerror = reject;
        reader.onload = () => {
            const img = new Image();
            img.onerror = reject;
            img.onload = () => {
                const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
                const canvas = document.createElement("canvas");
                canvas.width = Math.max(1, Math.round(img.width * scale));
                canvas.height = Math.max(1, Math.round(img.height * scale));
                const ctx = canvas.getContext("2d");
                ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                resolve(canvas.toDataURL("image/webp", quality));
            };
            img.src = reader.result;
        };
        reader.readAsDataURL(file);
    });
}

function loadProfile() {
    try {
        return JSON.parse(localStorage.getItem("pharma40-profile")) || {};
    } catch {
        return {};
    }
}

function loadNotifications() {
    try {
        const saved = JSON.parse(localStorage.getItem("pharma40-notifications"));
        if (Array.isArray(saved)) return saved;
    } catch {
        // Start with an empty notification center.
    }
    return [];
}

function saveNotifications() {
    localStorage.setItem("pharma40-notifications", JSON.stringify(appState.notifications.slice(0, 30)));
}

function pushNotification(title, message, type = "info", url = "", shouldRender = true) {
    appState.notifications = [{
        id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
        title,
        message,
        type,
        url,
        read: false,
        time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    }, ...appState.notifications].slice(0, 30);
    saveNotifications();
    if (shouldRender) render();
}

function themeOption(value, label) {
    return `<option value="${value}" ${appState.theme === value ? "selected" : ""}>${label}</option>`;
}

function sidebarModeOption(value, label) {
    return `<option value="${value}" ${appState.sidebarMode === value ? "selected" : ""}>${label}</option>`;
}

function emptyState(message) {
    return `<div class="muted">${message}</div>`;
}

function hydrateIcons() {
    if (window.lucide?.createIcons) {
        window.lucide.createIcons({ attrs: { width: 17, height: 17, "stroke-width": 2 } });
    }
}

function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function escapeAttribute(value) {
    return escapeHtml(value).replaceAll("\n", "&#10;");
}
