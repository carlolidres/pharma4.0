const DOCUMENT_HEADERS = [
    "Routing Tracker #",
    "Doc Tracer #",
    "Equipment/Product",
    "Category",
    "IL-Tag",
    "Status",
    "Sent/Routing To",
    "Email",
    "Date Sent",
    "Report/Protocol",
    "Batch No.",
    "Client Name",
    "Department",
    "Prepared By",
    "Date Prepared",
    "Checked By",
    "Date Checked",
    "Target Completion Date",
    "Remarks",
    "Created At",
    "Updated At",
    "Updated By"
];

const REGISTRY_MAP = {
    Status: ["Routing", "For Scanning", "Sent", "In EDMS", "Cancelled"],
    "Sent / Routing": ["Anissa", "Angela", "Fong", "Steve", "Jon", "Cara", "Kitel", "Aiza", "Ron", "Nadia", "Anne", "Tin", "Client", "Rev", "Ernz", "Othy", "Iya", "Isaiah", "Icel", "Jude", "Jojo", "Timi", "Karen", "Suzette", "Marvin", "Bing", "Lenie", "Venie"],
    "Report / Protocol": ["Protocol", "Report", "Val. Protocol", "Val. Report", "Ver. Protocol", "Ver. Report", "Char. Report", "Char. Protocol", "Endorsement", "Charac. Endorsement", "Others", "Interim Report", "Verif. Endorsement Report", "USV Endorsement", "Investigation Report"],
    Client: ["Abbott Philippines Inc.", "ADP Pharma Corporation", "Alliance Pharmaceutical Limited (UK)", "Aspen Philippines, Inc.", "Aspen Pharmacare Australia Pty Ltd", "ATC Healthcare International Corp.", "Bayer Philippines, Inc. – Pharma Division", "Bayer Philippines, Inc. – Consumer Care Division", "ENT Technologies Pty Ltd.", "Euro-med Laboratories Phil, Inc.", "Foundation Consumer Brands, LLC", "GlaxoSmithKline Consumer Healthcare (GSK / GSK CH)", "Haleon", "Hi-Eisai", "iNova Pharmaceuticals Philippines", "iNova Pharmaceuticals (Singapore) Pte. Ltd.", "Janssen Pharmaceutica", "J&J International (Singapore) Pte. Ltd.", "JNTL Consumer Health (Philippines), Inc.", "Kenvue", "Medchoice Pharma Inc.", "Mundipharma Distribution GmbH", "Novartis Healthcare Phils., Inc.", "Pascual Pharma Corp.", "Pfizer Inc.", "PF OFG Philippines, Inc.", "Sandoz Philippines Corp.", "Taisho Pharmaceuticals Philippines, Inc.", "The Cathay YSS Distributors Company, Inc.", "Trianon International, Inc.", "Viatris, Inc.", "Xeno Pharmaceutical", "Zoetis Philippines, Inc.", "Zuellig Pharma Corporation", "Interphil Laboratories Inc.", "NA"],
    Category: ["Process", "Non-process", "Others", "APR"],
    Department: ["DPM", "DPP", "LPM", "LPP", "SG", "CO", "Cepha", "TOP", "COS", "QA", "QC Plant 1", "QC Plant 2", "RnD", "Engr", "HR", "IT", "Plant 1", "Plant 2", "Dispensing", "WH Plant 1", "WH Plant 2", "Other"],
    "Prepared by": ["CML", "ADF", "NIV", "LAL", "RDM", "FBP", "FBP & LAL", "ADF & CML", "FBP & CML"],
    "Checked by": ["CML", "ADF", "NIV", "LAL", "RDM", "SBA"]
};

const FIELD_TO_REGISTRY = {
    "Status": "Status",
    "Sent/Routing To": "Sent / Routing",
    "Report/Protocol": "Report / Protocol",
    "Client Name": "Client",
    "Category": "Category",
    "Department": "Department",
    "Prepared By": "Prepared by",
    "Checked By": "Checked by"
};

const REQUIRED_FIELDS = [
    "Doc Tracer #",
    "Equipment/Product",
    "Category",
    "Status",
    "Sent/Routing To",
    "Report/Protocol",
    "Batch No.",
    "Client Name",
    "Department",
    "Prepared By",
    "Date Prepared",
    "Checked By",
    "Date Checked"
];

const ROUTING_FIELDS = DOCUMENT_HEADERS.filter(header => !["Created At", "Updated At", "Updated By"].includes(header));
const STORE_VERSION = "2026-05-16-vrms-tailadmin-v4";
const SENT_ROUTING_REGISTRY = "Sent / Routing";

const documentState = {
    theme: window.PharmaTheme?.current() || "light",
    collapsed: localStorage.getItem("pharma40-sidebar") === "collapsed",
    sidebarMode: localStorage.getItem("pharma40-sidebar-mode") || "click",
    activePage: "dashboard",
    profileOpen: false,
    notificationOpen: false,
    selectedRegistryType: "Status",
    editingTracker: "",
    databaseFilters: { search: "", status: "", client: "", department: "", category: "", sentTo: "" },
    searchMessage: "",
    toast: null,
    notifications: loadNotifications(),
    documents: loadDocuments(),
    registries: loadRegistries(),
    audit: loadAudit()
};

document.addEventListener("DOMContentLoaded", () => {
    documentState.theme = window.PharmaTheme?.apply(documentState.theme) || documentState.theme;
    renderDocuments();
});

function renderDocuments() {
    const root = document.getElementById("documentsRoot");
    root.innerHTML = documentsTemplate();
    wireDocuments();
    hydrateDocumentIcons();
}

function documentsTemplate() {
    const sidebarCollapsed = documentState.sidebarMode === "hover" || documentState.collapsed;
    return `
        <div class="app-shell documents-shell sidebar-mode-${documentState.sidebarMode} ${sidebarCollapsed ? "sidebar-collapsed" : ""}">
            ${sidebarTemplate()}
            <main class="main-workspace">
                ${topbarTemplate()}
                <section class="content documents-content">
                    ${pageTemplate()}
                </section>
            </main>
            <div id="toast" class="${documentState.toast ? "show" : ""}">${escapeHtml(documentState.toast || "")}</div>
        </div>
    `;
}

function sidebarTemplate() {
    const items = [
        ["dashboard", "Dashboard", "layout-dashboard"],
        ["routing", "Document Routing", "file-text"],
        ["database", "Database", "database"],
        ["audit", "Audit Trail", "history"],
        ["registry", "Registry", "settings-2"]
    ];

    return `
        <aside class="sidebar">
            <div class="brand-row brand-link" aria-label="Pharma 4.0">
                <div class="brand-mark">P4</div>
                <div class="brand-copy">
                    <strong>Pharma 4.0</strong>
                    <span>Validation Management</span>
                </div>
            </div>
            <nav class="side-nav" aria-label="VRMS navigation">
                ${items.map(([page, label, icon]) => `
                    <button class="nav-item ${documentState.activePage === page ? "active" : ""}" data-page="${page}" type="button" title="${label}">
                        <span class="nav-icon"><i data-lucide="${icon}"></i></span>
                        <span class="nav-label">${label}</span>
                    </button>
                `).join("")}
            </nav>
            ${documentState.sidebarMode === "click" ? `<div class="sidebar-toggle-wrap">
                <button class="sidebar-toggle" id="sidebarToggle" type="button" aria-label="Toggle sidebar">
                    <i data-lucide="${documentState.collapsed ? "panel-right-open" : "panel-left-close"}"></i>
                    <span class="toggle-label">Collapse</span>
                </button>
            </div>` : ""}
        </aside>
    `;
}

function topbarTemplate() {
    return `
        <header class="topbar">
            <button class="mobile-menu-button" id="mobileMenuButton" type="button" aria-label="Toggle sidebar"><i data-lucide="menu"></i></button>
            <div class="topbar-title">
                <strong>Document Management and Routing System</strong>
                <span>VRMS controlled document workspace</span>
            </div>
            <div class="topbar-actions">
                ${notificationBellTemplate()}
                <button class="profile-button" id="profileButton" type="button" aria-expanded="${documentState.profileOpen}">
                    <span class="avatar">${escapeHtml(window.PHARMA40_USER.initials)}</span>
                    <span class="profile-copy">
                        <strong>${escapeHtml(window.PHARMA40_USER.fullName)}</strong>
                        <span>${escapeHtml(window.PHARMA40_USER.role)}</span>
                    </span>
                    <i data-lucide="chevron-down"></i>
                </button>
                ${notificationPanelTemplate()}
                ${profileMenuTemplate()}
            </div>
        </header>
    `;
}

function notificationBellTemplate() {
    const unread = documentState.notifications.filter(item => !item.read).length;
    return `
        <button class="notification-button" id="notificationButton" type="button" aria-label="Notifications" aria-expanded="${documentState.notificationOpen}">
            <i data-lucide="bell"></i>
            ${unread ? `<span class="notification-count">${Math.min(unread, 9)}</span>` : ""}
        </button>
    `;
}

function notificationPanelTemplate() {
    const items = documentState.notifications.slice(0, 8);
    return `
        <div class="notification-panel ${documentState.notificationOpen ? "open" : ""}" id="notificationPanel">
            <div class="notification-head">
                <div>
                    <strong>Notifications</strong>
                    <span>${items.length ? "Recent VRMS activity" : "No recent activity"}</span>
                </div>
                <button class="btn-ghost" id="markNotificationsRead" type="button">Mark read</button>
            </div>
            <div class="notification-list">
                ${items.map(notificationItemTemplate).join("") || `<div class="empty-state">No notifications yet.</div>`}
            </div>
        </div>
    `;
}

function notificationItemTemplate(item) {
    const content = `
        <span class="notification-dot"></span>
        <span>
            <span class="notification-title">${escapeHtml(item.title)}<span class="notification-time">${escapeHtml(item.time)}</span></span>
            <span class="notification-copy">${escapeHtml(item.message)}</span>
        </span>
    `;
    if (item.url) {
        return `<a class="notification-item ${item.read ? "read" : ""}" href="${escapeAttribute(item.url)}" target="_blank" rel="noopener noreferrer">${content}</a>`;
    }
    return `<div class="notification-item ${item.read ? "read" : ""}">${content}</div>`;
}

function themeOption(value, label) {
    return `<option value="${value}" ${documentState.theme === value ? "selected" : ""}>${label}</option>`;
}

function profileMenuTemplate() {
    return `
        <div class="profile-menu tailadmin-profile-menu ${documentState.profileOpen ? "open" : ""}" id="profileMenu">
            <div class="profile-summary">
                <span class="avatar profile-avatar">${escapeHtml(window.PHARMA40_USER.initials)}</span>
                <div class="profile-copy">
                    <strong>${escapeHtml(window.PHARMA40_USER.fullName)}</strong>
                    <span>${escapeHtml(window.PHARMA40_USER.email || "")}</span>
                    <span>${escapeHtml(window.PHARMA40_USER.userId || "")}</span>
                </div>
            </div>
            <div class="profile-section-title">Workspace</div>
            <div class="profile-field">
                <label for="documentThemeSelect">Theme</label>
                <select id="documentThemeSelect">
                    ${themeOption("light", "Light")}
                    ${themeOption("dark", "Dark")}
                    ${themeOption("night", "Night")}
                </select>
            </div>
            <button class="profile-menu-item" data-profile-page="dashboard" type="button"><i data-lucide="layout-dashboard"></i> Dashboard</button>
            <button class="profile-menu-item" data-profile-page="database" type="button"><i data-lucide="database"></i> Database</button>
            <a class="profile-menu-item" href="/Dashboard"><i data-lucide="grid-2x2"></i> Launch Pad</a>
            <a class="profile-menu-item danger" href="/Logout"><i data-lucide="log-out"></i> Logout</a>
        </div>
    `;
}

function pageTemplate() {
    if (documentState.activePage === "routing") return routingPage();
    if (documentState.activePage === "database") return databasePage();
    if (documentState.activePage === "audit") return auditPage();
    if (documentState.activePage === "registry") return registryPage();
    return dashboardPage();
}

function pageHeader(title, copy, actions = "") {
    return `
        <section class="documents-hero compact">
            <div>
                <p class="eyebrow">VRMS - Validation routing</p>
                <h1 class="hero-title">${escapeHtml(title)}</h1>
                <p class="hero-copy">${escapeHtml(copy)}</p>
            </div>
            <div class="documents-toolbar">${actions}</div>
        </section>
    `;
}

function dashboardPage() {
    const dashboard = buildDashboard();
    return `
        ${pageHeader("Dashboard", "Real-time validation routing overview", `<button class="btn-ghost" id="exportButton" type="button"><i data-lucide="download"></i> Export CSV</button>`)}
        <section class="documents-kpi-grid eight">
            ${kpiCard("slate", "Total", dashboard.total, "file-text")}
            ${kpiCard("amber", "Routing", dashboard.routing, "send")}
            ${kpiCard("orange", "For Scanning", dashboard.forScanning, "scan-line")}
            ${kpiCard("pink", "Sent", dashboard.sent, "check-circle-2")}
            ${kpiCard("blue", "In EDMS", dashboard.inEdms, "archive")}
            ${kpiCard("red", "Cancelled", dashboard.cancelled, "circle-x")}
            ${kpiCard("rose", "Overdue", dashboard.overdue, "alarm-clock")}
            ${kpiCard("slate", "Avg. Aging", `${dashboard.avgAging}d`, "clock")}
        </section>
        <section class="documents-status-grid">
            <article class="panel">
                <div class="panel-header no-filter">
                    <div>
                        <h2 class="section-title">Documents by Status</h2>
                        <p class="section-copy">Status distribution based on the current document database.</p>
                    </div>
                </div>
                <div class="dialog-body">${statusBars(dashboard.statusCounts)}</div>
            </article>
        </section>
        <section class="documents-dashboard-grid document-lists-grid">
            <article class="panel">
                <div class="panel-header no-filter">
                    <div>
                        <h2 class="section-title">Recently Updated Documents</h2>
                        <p class="section-copy">Latest records by updated timestamp.</p>
                    </div>
                </div>
                ${prototypeTable(dashboard.recent, ["Routing Tracker #", "Doc Tracer #", "Equipment/Product", "Status", "Sent/Routing To", "Date Sent"])}
            </article>
            <article class="panel">
                <div class="panel-header no-filter">
                    <div>
                        <h2 class="section-title">Active Routing Documents</h2>
                        <p class="section-copy">Records currently marked as Routing.</p>
                    </div>
                </div>
                ${prototypeTable(dashboard.active, ["Routing Tracker #", "Doc Tracer #", "Equipment/Product", "Status", "Sent/Routing To", "Date Sent"])}
            </article>
        </section>
    `;
}

function routingPage() {
    const record = getEditingRecord() || blankRecord();
    return `
        ${pageHeader("Document Routing", "Create new records or search and update existing ones")}
        <section class="documents-form-grid">
            <article class="panel">
                <div class="panel-header no-filter">
                    <div>
                        <h2 class="section-title">Document Routing Form</h2>
                        <p class="section-copy">Blank tracker values are assigned a unique 4-character routing tracker on save.</p>
                    </div>
                </div>
                <form id="routingForm" class="dialog-body documents-form prototype-form">
                    ${ROUTING_FIELDS.map(fieldName => inputFor(fieldName, record[fieldName])).join("")}
                    <div class="dialog-actions full">
                        <button class="btn-ghost" id="clearRoutingButton" type="button">Clear</button>
                        <button class="btn-primary" type="submit"><i data-lucide="save"></i> Submit</button>
                    </div>
                </form>
            </article>
            <article class="panel">
                <div class="panel-header no-filter">
                    <div>
                        <h2 class="section-title">Load Document / Search and Update</h2>
                        <p class="section-copy">Search by Routing Tracker # to load the existing record.</p>
                    </div>
                </div>
                <div class="dialog-body">
                    <div class="search-row">
                        <input id="searchTracker" type="text" placeholder="Enter 4-character Tracking Number" maxlength="12" />
                        <button class="btn-primary" id="searchTrackerButton" type="button">Search</button>
                    </div>
                    <p class="empty-state slim">${escapeHtml(documentState.searchMessage || "Search by Routing Tracker # to load and update.")}</p>
                </div>
            </article>
        </section>
    `;
}

function databasePage() {
    const rows = filteredDatabaseRows();
    return `
        ${pageHeader("Database", `${documentState.documents.length} records`, `<button class="btn-ghost" id="exportButton" type="button"><i data-lucide="download"></i> Export CSV</button>`)}
        <article class="panel">
            <div class="documents-filters database">
                <input id="dbSearch" type="search" placeholder="Search all fields..." value="${escapeAttribute(documentState.databaseFilters.search)}" />
                ${databaseSelect("dbStatus", "status", "All Statuses", registryValues("Status"))}
                ${databaseSelect("dbClient", "client", "All Clients", registryValues("Client"))}
                ${databaseSelect("dbDepartment", "department", "All Departments", registryValues("Department"))}
                ${databaseSelect("dbCategory", "category", "All Categories", registryValues("Category"))}
                ${databaseSelect("dbSentTo", "sentTo", "All Routed To", registryValues("Sent / Routing"))}
                <button class="icon-button" id="clearDbFiltersButton" type="button" title="Clear filters"><i data-lucide="x"></i></button>
            </div>
            <div id="databaseTableHost">
                ${prototypeTable(rows, ["Routing Tracker #", "Doc Tracer #", "Equipment/Product", "Category", "IL-Tag", "Status", "Sent/Routing To", "Email", "Date Sent", "Report/Protocol", "Client Name", "Department"])}
            </div>
        </article>
    `;
}

function auditPage() {
    return `
        ${pageHeader("Audit Trail", "Create, update, registry, and archive activity")}
        <article class="panel">
            ${auditTable(documentState.audit)}
        </article>
    `;
}

function registryPage() {
    const types = Object.keys(documentState.registries);
    const values = registryEntries(documentState.selectedRegistryType);
    const managesEmail = documentState.selectedRegistryType === SENT_ROUTING_REGISTRY;
    return `
        ${pageHeader("Registry / Master Data", "Manage dropdown values for forms. Deleted values are deactivated for traceability.")}
        <article class="panel">
            <div class="documents-filters registry ${managesEmail ? "registry-email-mode" : ""}">
                <select id="registryTypeSelect">
                    ${types.map(type => `<option value="${escapeAttribute(type)}" ${type === documentState.selectedRegistryType ? "selected" : ""}>${escapeHtml(type)}</option>`).join("")}
                </select>
                <input id="registryValueInput" type="text" placeholder="Add new value" />
                ${managesEmail ? `<input id="registryEmailInput" type="email" placeholder="Email address" />` : ""}
                <button class="btn-primary" id="addRegistryButton" type="button"><i data-lucide="plus"></i></button>
            </div>
            ${managesEmail ? sentRoutingRegistryTable(values) : standardRegistryList(values)}
        </article>
    `;
}

function standardRegistryList(values) {
    return `
        <div class="registry-list">
            ${values.map(entry => `
                <div class="registry-row ${entry.active === false ? "inactive" : ""}">
                    <span>${escapeHtml(entry.value)}</span>
                    <span class="detail-muted">${entry.active === false ? "Inactive" : "Active"}</span>
                    ${entry.active === false
                        ? `<button class="btn-ghost" data-restore-registry="${escapeAttribute(entry.value)}" type="button">Restore</button>`
                        : `<button class="registry-danger" data-delete-registry="${escapeAttribute(entry.value)}" type="button">Deactivate</button>`}
                </div>
            `).join("") || `<div class="empty-state">No registry values configured.</div>`}
        </div>
    `;
}

function sentRoutingRegistryTable(values) {
    if (!values.length) return `<div class="empty-state">No routing recipients configured.</div>`;
    return `
        <div class="documents-table-wrap registry-email-table">
            <table class="documents-table">
                <thead>
                    <tr>
                        <th>Sent/Routing To</th>
                        <th>Email Address</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    ${values.map(entry => `
                        <tr class="${entry.active === false ? "inactive" : ""}">
                            <td><span class="registry-name">${escapeHtml(entry.value)}</span></td>
                            <td>
                                <input class="registry-email-field" data-registry-email="${escapeAttribute(entry.value)}" type="email" value="${escapeAttribute(entry.email || "")}" placeholder="No email registered" />
                            </td>
                            <td><span class="detail-muted">${entry.active === false ? "Inactive" : "Active"}</span></td>
                            <td>
                                <div class="table-actions">
                                    <button class="btn-soft" data-update-registry-email="${escapeAttribute(entry.value)}" type="button">Save Email</button>
                                    ${entry.active === false
                                        ? `<button class="btn-ghost" data-restore-registry="${escapeAttribute(entry.value)}" type="button">Restore</button>`
                                        : `<button class="registry-danger" data-delete-registry="${escapeAttribute(entry.value)}" type="button">Deactivate</button>`}
                                </div>
                            </td>
                        </tr>
                    `).join("")}
                </tbody>
            </table>
        </div>
    `;
}

function eSignaturePage() {
    return `
        ${pageHeader("eSignatures", "Capture assigned reviewer or approver decisions with remarks and audit history.")}
        <article class="panel">
            ${prototypeTable(documentState.documents, ["Routing Tracker #", "Doc Tracer #", "Equipment/Product", "Status", "Sent/Routing To", "Updated At"])}
            <div class="detail-stack esignature-list">
                ${documentState.documents.map(record => `
                    <div class="signature-row">
                        <strong>${escapeHtml(record["Routing Tracker #"])} - ${escapeHtml(record["Doc Tracer #"])}</strong>
                        <div class="detail-muted">Assigned to ${escapeHtml(record["Sent/Routing To"] || "N/A")} - ${escapeHtml(record.Status || "Blank")}</div>
                        <div class="search-row">
                            <select data-esign-action="${escapeAttribute(record["Routing Tracker #"])}">
                                <option>Reviewed</option>
                                <option>Approved</option>
                                <option>Returned</option>
                                <option>Rejected</option>
                            </select>
                            <input data-esign-remarks="${escapeAttribute(record["Routing Tracker #"])}" placeholder="Remarks required for Returned/Rejected" />
                            <button class="btn-primary" data-esign-submit="${escapeAttribute(record["Routing Tracker #"])}" type="button">Sign</button>
                        </div>
                    </div>
                `).join("")}
            </div>
        </article>
    `;
}

function kpiCard(color, label, value, icon) {
    return `
        <article class="kpi-card ${color}">
            <div>
                <span class="kpi-label">${escapeHtml(label)}</span>
                <strong class="kpi-value">${escapeHtml(value ?? 0)}</strong>
            </div>
            <span class="kpi-icon"><i data-lucide="${icon}"></i></span>
        </article>
    `;
}

function inputFor(fieldName, value = "") {
    const required = REQUIRED_FIELDS.includes(fieldName);
    const registryType = FIELD_TO_REGISTRY[fieldName];
    const isDate = fieldName.includes("Date");
    const isEmail = fieldName === "Email";
    const className = ["Equipment/Product", "Department", "Remarks", "Target Completion Date"].includes(fieldName) ? "wide" : "";
    const label = `${fieldName}${required ? " *" : ""}`;

    if (fieldName === "Remarks") {
        return `<label class="${className}">${escapeHtml(label)}<textarea name="${escapeAttribute(fieldName)}">${escapeHtml(value || "")}</textarea></label>`;
    }

    if (isEmail) {
        const recipient = getEditingRecord()?.["Sent/Routing To"] || "";
        const emailValue = value || getRoutingRecipientEmail(recipient);
        const hasRecipient = Boolean(recipient);
        const hasRegistryEmail = Boolean(getRoutingRecipientEmail(recipient));
        return `
            <label class="${className}">${escapeHtml(label)}
                <input id="routingEmailField" name="${escapeAttribute(fieldName)}" type="email" value="${escapeAttribute(emailValue || "")}" ${required ? "required" : ""} />
                <span id="routingEmailHelper" class="field-helper ${hasRecipient && !hasRegistryEmail ? "warning" : ""}">
                    ${hasRecipient && !hasRegistryEmail ? "No email address registered for this routing recipient." : "Manual edits here do not update the registry email."}
                </span>
            </label>
        `;
    }

    if (registryType) {
        return `
            <label class="${className}">${escapeHtml(label)}
                <select name="${escapeAttribute(fieldName)}" ${fieldName === "Sent/Routing To" ? "id=\"sentRoutingSelect\"" : ""} ${required ? "required" : ""}>
                    <option value="">Select ${escapeHtml(fieldName)}</option>
                    ${registryValues(registryType).map(item => `<option value="${escapeAttribute(item)}" ${item === value ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}
                </select>
            </label>
        `;
    }

    return `
        <label class="${className}">${escapeHtml(label)}
            <input name="${escapeAttribute(fieldName)}" type="${isDate ? "date" : "text"}" value="${escapeAttribute(value || "")}" ${required ? "required" : ""} ${fieldName === "Routing Tracker #" ? "maxlength=\"12\"" : ""} />
        </label>
    `;
}

function databaseSelect(id, key, label, values) {
    const selected = documentState.databaseFilters[key] || "";
    return `
        <select id="${id}">
            <option value="">${escapeHtml(label)}</option>
            ${values.map(value => `<option value="${escapeAttribute(value)}" ${value === selected ? "selected" : ""}>${escapeHtml(value)}</option>`).join("")}
        </select>
    `;
}

function prototypeTable(rows, headers) {
    if (!rows.length) {
        return `<p class="empty-state">No records found.</p>`;
    }

    return `
        <div class="documents-table-wrap">
            <table class="documents-table prototype-table">
                <thead><tr>${headers.map(header => `<th>${escapeHtml(header)}</th>`).join("")}</tr></thead>
                <tbody>
                    ${rows.map(row => `
                        <tr>${headers.map(header => `<td>${header === "Status" ? statusPill(row[header]) : escapeHtml(row[header] || "")}</td>`).join("")}</tr>
                    `).join("")}
                </tbody>
            </table>
        </div>
    `;
}

function auditTable(rows) {
    if (!rows.length) {
        return `<p class="empty-state">No audit events captured.</p>`;
    }

    const headers = ["Timestamp", "User", "Action", "Routing Tracker #", "Doc Tracer #", "Details"];
    return `
        <div class="documents-table-wrap">
            <table class="documents-table audit-table">
                <thead><tr>${headers.map(header => `<th>${escapeHtml(header)}</th>`).join("")}</tr></thead>
                <tbody>
                    ${rows.map(row => `
                        <tr>
                            <td>${escapeHtml(row.Timestamp || "")}</td>
                            <td>${escapeHtml(row.User || "")}</td>
                            <td>${escapeHtml(row.Action || "")}</td>
                            <td>${escapeHtml(row["Routing Tracker #"] || "")}</td>
                            <td>${escapeHtml(row["Doc Tracer #"] || "")}</td>
                            <td class="audit-details">${escapeHtml(row.Details || "")}</td>
                        </tr>
                    `).join("")}
                </tbody>
            </table>
        </div>
    `;
}

function statusBars(counts = {}) {
    const entries = Object.entries(counts).map(([status, count]) => ({ status, count: Number(count) || 0 }));
    const max = Math.max(1, ...entries.map(item => item.count));
    return `
        <div class="status-bars">
            ${entries.map(item => `
                <div class="status-bar-row status-tone-${statusClass(item.status)}">
                    <span>${escapeHtml(item.status)}</span>
                    <div class="status-bar-track"><div class="status-bar-fill" style="width:${Math.max(4, (item.count / max) * 100)}%"></div></div>
                    <strong>${item.count}</strong>
                </div>
            `).join("") || `<p class="empty-state">No status data.</p>`}
        </div>
    `;
}

function wireDocuments() {
    const shell = document.querySelector(".app-shell");
    const sidebar = document.querySelector(".sidebar");

    sidebar?.addEventListener("mouseenter", () => {
        if (documentState.sidebarMode === "hover") shell?.classList.add("sidebar-hovered");
    });
    sidebar?.addEventListener("mouseleave", () => {
        if (documentState.sidebarMode === "hover") shell?.classList.remove("sidebar-hovered");
    });
    document.getElementById("sidebarToggle")?.addEventListener("click", () => {
        documentState.collapsed = !documentState.collapsed;
        localStorage.setItem("pharma40-sidebar", documentState.collapsed ? "collapsed" : "expanded");
        renderDocuments();
    });
    document.getElementById("mobileMenuButton")?.addEventListener("click", () => {
        documentState.collapsed = !documentState.collapsed;
        localStorage.setItem("pharma40-sidebar", documentState.collapsed ? "collapsed" : "expanded");
        renderDocuments();
    });
    document.querySelectorAll("[data-page]").forEach(button => {
        button.addEventListener("click", () => {
            documentState.activePage = button.dataset.page;
            documentState.searchMessage = "";
            renderDocuments();
        });
    });
    document.getElementById("profileButton")?.addEventListener("click", event => {
        event.stopPropagation();
        documentState.profileOpen = !documentState.profileOpen;
        documentState.notificationOpen = false;
        renderDocuments();
    });
    document.getElementById("notificationButton")?.addEventListener("click", event => {
        event.stopPropagation();
        documentState.notificationOpen = !documentState.notificationOpen;
        documentState.profileOpen = false;
        if (documentState.notificationOpen) {
            documentState.notifications = documentState.notifications.map(item => ({ ...item, read: true }));
            saveNotifications();
        }
        renderDocuments();
    });
    document.getElementById("profileMenu")?.addEventListener("click", event => event.stopPropagation());
    document.getElementById("notificationPanel")?.addEventListener("click", event => event.stopPropagation());
    document.getElementById("markNotificationsRead")?.addEventListener("click", () => {
        documentState.notifications = documentState.notifications.map(item => ({ ...item, read: true }));
        saveNotifications();
        documentState.notificationOpen = true;
        renderDocuments();
    });
    document.getElementById("documentThemeSelect")?.addEventListener("change", event => {
        documentState.theme = window.PharmaTheme?.apply(event.target.value) || event.target.value;
        documentState.profileOpen = true;
        renderDocuments();
    });
    document.querySelectorAll("[data-profile-page]").forEach(button => {
        button.addEventListener("click", () => {
            documentState.activePage = button.dataset.profilePage;
            documentState.profileOpen = false;
            renderDocuments();
        });
    });
    document.addEventListener("click", closeProfileOnce, { once: true });

    document.getElementById("exportButton")?.addEventListener("click", exportCsv);
    document.getElementById("routingForm")?.addEventListener("submit", saveDocument);
    document.getElementById("clearRoutingButton")?.addEventListener("click", () => {
        documentState.editingTracker = "";
        documentState.searchMessage = "";
        renderDocuments();
    });
    document.getElementById("searchTrackerButton")?.addEventListener("click", loadTracker);
    document.getElementById("searchTracker")?.addEventListener("keydown", event => {
        if (event.key === "Enter") loadTracker();
    });
    document.getElementById("sentRoutingSelect")?.addEventListener("change", event => {
        applyRoutingRecipientEmail(event.target.value, true);
    });

    bindDatabaseFilter("dbSearch", "search");
    bindDatabaseFilter("dbStatus", "status");
    bindDatabaseFilter("dbClient", "client");
    bindDatabaseFilter("dbDepartment", "department");
    bindDatabaseFilter("dbCategory", "category");
    bindDatabaseFilter("dbSentTo", "sentTo");
    document.getElementById("clearDbFiltersButton")?.addEventListener("click", () => {
        documentState.databaseFilters = { search: "", status: "", client: "", department: "", category: "", sentTo: "" };
        renderDocuments();
    });

    document.getElementById("registryTypeSelect")?.addEventListener("change", event => {
        documentState.selectedRegistryType = event.target.value;
        renderDocuments();
    });
    document.getElementById("addRegistryButton")?.addEventListener("click", addRegistryValue);
    document.getElementById("registryValueInput")?.addEventListener("keydown", event => {
        if (event.key === "Enter") addRegistryValue();
    });
    document.getElementById("registryEmailInput")?.addEventListener("keydown", event => {
        if (event.key === "Enter") addRegistryValue();
    });
    document.querySelectorAll("[data-update-registry-email]").forEach(button => {
        button.addEventListener("click", () => updateRegistryEmail(button.dataset.updateRegistryEmail));
    });
    document.querySelectorAll("[data-delete-registry]").forEach(button => {
        button.addEventListener("click", () => deactivateRegistryValue(button.dataset.deleteRegistry));
    });
    document.querySelectorAll("[data-restore-registry]").forEach(button => {
        button.addEventListener("click", () => restoreRegistryValue(button.dataset.restoreRegistry));
    });
    document.querySelectorAll("[data-esign-submit]").forEach(button => {
        button.addEventListener("click", () => saveESignature(button.dataset.esignSubmit));
    });
}

function bindDatabaseFilter(id, key) {
    const element = document.getElementById(id);
    element?.addEventListener("input", event => {
        documentState.databaseFilters[key] = event.target.value;
        if (key === "search") updateDatabaseTable();
    });
    element?.addEventListener("change", event => {
        documentState.databaseFilters[key] = event.target.value;
        updateDatabaseTable();
    });
}

function closeProfileOnce() {
    if (documentState.profileOpen || documentState.notificationOpen) {
        documentState.profileOpen = false;
        documentState.notificationOpen = false;
        renderDocuments();
    }
}

function updateDatabaseTable() {
    const host = document.getElementById("databaseTableHost");
    if (!host) return;
    host.innerHTML = prototypeTable(filteredDatabaseRows(), ["Routing Tracker #", "Doc Tracer #", "Equipment/Product", "Category", "IL-Tag", "Status", "Sent/Routing To", "Email", "Date Sent", "Report/Protocol", "Client Name", "Department"]);
    hydrateDocumentIcons();
}

function applyRoutingRecipientEmail(recipient, shouldReplace) {
    const emailField = document.getElementById("routingEmailField");
    const helper = document.getElementById("routingEmailHelper");
    if (!emailField) return;

    const registryEmail = getRoutingRecipientEmail(recipient);
    if (shouldReplace) emailField.value = registryEmail || "";

    if (helper) {
        helper.classList.toggle("warning", Boolean(recipient && !registryEmail));
        helper.textContent = recipient && !registryEmail
            ? "No email address registered for this routing recipient."
            : "Manual edits here do not update the registry email.";
    }
}

function getRoutingRecipientEmail(recipient) {
    if (!recipient) return "";
    const found = registryEntries(SENT_ROUTING_REGISTRY).find(entry => entry.active !== false && same(entry.value, recipient));
    return String(found?.email || "").trim();
}

function saveDocument(event) {
    event.preventDefault();
    const form = new FormData(event.target);
    const payload = {};
    ROUTING_FIELDS.forEach(fieldName => payload[fieldName] = String(form.get(fieldName) || "").trim());

    if (!payload["Doc Tracer #"]) {
        showToast("Document Tracer Number is required.");
        return;
    }

    let routingTracker = payload["Routing Tracker #"].toUpperCase();
    if (!routingTracker) routingTracker = generateUniqueTracker();

    const originalTracker = documentState.editingTracker || "";
    const originalRecord = originalTracker
        ? documentState.documents.find(row => same(row["Routing Tracker #"], originalTracker))
        : null;
    const existingByTracker = documentState.documents.find(row => same(row["Routing Tracker #"], routingTracker));
    const duplicateDocTracer = documentState.documents.find(row =>
        same(row["Doc Tracer #"], payload["Doc Tracer #"]) &&
        !same(row["Routing Tracker #"], originalTracker || routingTracker));

    if (duplicateDocTracer) {
        showToast(`Document already existing. Tracking number assigned: ${duplicateDocTracer["Routing Tracker #"]}`);
        return;
    }

    if (existingByTracker && originalTracker && !same(existingByTracker["Routing Tracker #"], originalTracker)) {
        showToast(`Routing tracker already existing. Tracking number assigned: ${routingTracker}`);
        return;
    }

    if (existingByTracker && !originalTracker) {
        showToast(`Routing tracker already existing. Tracking number assigned: ${routingTracker}`);
        return;
    }

    const now = formatDateTimeValue(new Date());
    const user = window.PHARMA40_USER.email || window.PHARMA40_USER.fullName || "Unknown user";
    const existing = originalRecord || existingByTracker || {};
    const record = {};
    DOCUMENT_HEADERS.forEach(header => record[header] = payload[header] || existing[header] || "");
    record["Routing Tracker #"] = routingTracker;
    record["Doc Tracer #"] = payload["Doc Tracer #"];
    record["Created At"] = existing["Created At"] || now;
    record["Updated At"] = now;
    record["Updated By"] = user;

    if (originalRecord || existingByTracker) {
        const previousTracker = originalTracker || routingTracker;
        documentState.documents = documentState.documents.map(row => same(row["Routing Tracker #"], previousTracker) ? record : row);
        logAudit("Updated document", routingTracker, record["Doc Tracer #"], JSON.stringify(diffRecord(existing, record)));
    } else {
        documentState.documents.push(record);
        logAudit("Created document", routingTracker, record["Doc Tracer #"], "New document routing record created.");
    }

    documentState.editingTracker = routingTracker;
    persistAll();
    showToast("Document saved.");
    renderDocuments();
}

function loadTracker() {
    const value = String(document.getElementById("searchTracker")?.value || "").trim().toUpperCase();
    const found = documentState.documents.find(row => same(row["Routing Tracker #"], value));
    if (!found) {
        documentState.searchMessage = `No document found for tracking number: ${value || "blank"}`;
        showToast(documentState.searchMessage);
        renderDocuments();
        return;
    }

    documentState.editingTracker = found["Routing Tracker #"];
    documentState.searchMessage = `Loaded ${found["Routing Tracker #"]} / ${found["Doc Tracer #"]}.`;
    showToast("Document loaded.");
    renderDocuments();
}

function addRegistryValue() {
    const value = String(document.getElementById("registryValueInput")?.value || "").trim();
    const email = String(document.getElementById("registryEmailInput")?.value || "").trim();
    const type = documentState.selectedRegistryType;
    if (!value) {
        showToast("Value is required.");
        return;
    }

    if (type === SENT_ROUTING_REGISTRY && email && !isValidEmail(email)) {
        showToast("Enter a valid email address.");
        return;
    }

    const entries = registryEntries(type);
    const existing = entries.find(entry => same(entry.value, value));
    if (existing) {
        const wasInactive = existing.active === false;
        existing.active = true;
        if (type === SENT_ROUTING_REGISTRY && email) existing.email = email;
        logAudit(wasInactive ? "Restored registry value" : "Updated registry value", "", "", `${type}: ${value}`);
    } else {
        entries.push({ value, active: true, ...(type === SENT_ROUTING_REGISTRY ? { email } : {}) });
        logAudit("Added registry value", "", "", `${type}: ${value}`);
    }

    documentState.registries[type] = entries;
    persistAll();
    showToast("Registry updated.");
    renderDocuments();
}

function updateRegistryEmail(value) {
    const entries = registryEntries(SENT_ROUTING_REGISTRY);
    const found = entries.find(entry => same(entry.value, value));
    if (!found) return;

    const email = String(document.querySelector(`[data-registry-email="${cssEscape(value)}"]`)?.value || "").trim();
    if (email && !isValidEmail(email)) {
        showToast("Enter a valid email address.");
        return;
    }

    const previous = found.email || "";
    found.email = email;
    documentState.registries[SENT_ROUTING_REGISTRY] = entries;
    logAudit("Updated routing recipient email", "", "", `${value}: ${previous || "Blank"} -> ${email || "Blank"}`);
    persistAll();
    showToast("Email address updated.");
    renderDocuments();
}

function deactivateRegistryValue(value) {
    const type = documentState.selectedRegistryType;
    const entries = registryEntries(type);
    const found = entries.find(entry => entry.value === value);
    if (!found) return;
    found.active = false;
    documentState.registries[type] = entries;
    logAudit("Deactivated registry value", "", "", `${type}: ${value}`);
    persistAll();
    showToast("Registry value deactivated.");
    renderDocuments();
}

function restoreRegistryValue(value) {
    const type = documentState.selectedRegistryType;
    const entries = registryEntries(type);
    const found = entries.find(entry => entry.value === value);
    if (!found) return;
    found.active = true;
    documentState.registries[type] = entries;
    logAudit("Restored registry value", "", "", `${type}: ${value}`);
    persistAll();
    showToast("Registry value restored.");
    renderDocuments();
}

function saveESignature(tracker) {
    const record = documentState.documents.find(row => same(row["Routing Tracker #"], tracker));
    if (!record) return;
    const action = document.querySelector(`[data-esign-action="${cssEscape(tracker)}"]`)?.value || "Reviewed";
    const remarks = String(document.querySelector(`[data-esign-remarks="${cssEscape(tracker)}"]`)?.value || "").trim();
    if (["Returned", "Rejected"].includes(action) && !remarks) {
        showToast("Remarks are required when returning or rejecting a document.");
        return;
    }

    record.Status = action === "Approved" ? "Sent" : action === "Returned" ? "Routing" : action === "Rejected" ? "Cancelled" : record.Status;
    record["Updated At"] = formatDateTimeValue(new Date());
    record["Updated By"] = window.PHARMA40_USER.email || window.PHARMA40_USER.fullName || "Unknown user";
    logAudit(`eSignature ${action}`, record["Routing Tracker #"], record["Doc Tracer #"], `${window.PHARMA40_USER.fullName} signed. ${remarks || "No remarks."}`);
    persistAll();
    showToast("eSignature captured.");
    renderDocuments();
}

function filteredDatabaseRows() {
    const filters = documentState.databaseFilters;
    return documentState.documents.filter(row => {
        const haystack = Object.values(row).join(" ").toLowerCase();
        return (!filters.search || haystack.includes(filters.search.toLowerCase())) &&
            (!filters.status || row.Status === filters.status) &&
            (!filters.client || row["Client Name"] === filters.client) &&
            (!filters.department || row.Department === filters.department) &&
            (!filters.category || row.Category === filters.category) &&
            (!filters.sentTo || row["Sent/Routing To"] === filters.sentTo);
    });
}

function buildDashboard() {
    const statusCounts = {};
    documentState.documents.forEach(doc => {
        const status = doc.Status || "Blank";
        statusCounts[status] = (statusCounts[status] || 0) + 1;
    });

    const routingDocs = documentState.documents.filter(doc => doc.Status === "Routing");
    const aging = routingDocs.map(doc => daysBetween(doc["Date Sent"], new Date())).filter(days => days >= 0);

    return {
        total: documentState.documents.length,
        routing: statusCounts.Routing || 0,
        forScanning: statusCounts["For Scanning"] || 0,
        sent: statusCounts.Sent || 0,
        inEdms: statusCounts["In EDMS"] || 0,
        cancelled: statusCounts.Cancelled || 0,
        overdue: documentState.documents.filter(isOverdue).length,
        avgAging: aging.length ? Math.round(aging.reduce((sum, days) => sum + days, 0) / aging.length) : 0,
        statusCounts,
        recent: [...documentState.documents].sort((a, b) => new Date(b["Updated At"]) - new Date(a["Updated At"])).slice(0, 8),
        active: routingDocs.slice(0, 12)
    };
}

function isOverdue(doc) {
    if (!doc["Target Completion Date"] || ["Sent", "In EDMS", "Cancelled"].includes(doc.Status)) return false;
    const target = new Date(doc["Target Completion Date"]);
    const today = new Date();
    target.setHours(0, 0, 0, 0);
    today.setHours(0, 0, 0, 0);
    return target < today;
}

function getEditingRecord() {
    return documentState.documents.find(row => same(row["Routing Tracker #"], documentState.editingTracker));
}

function blankRecord() {
    const today = formatDateValue(new Date());
    const record = {};
    DOCUMENT_HEADERS.forEach(header => record[header] = "");
    record["Routing Tracker #"] = generateUniqueTracker();
    record.Status = "Routing";
    record["Date Sent"] = today;
    record["Date Prepared"] = today;
    record["Date Checked"] = today;
    record["Prepared By"] = registryValues("Prepared by")[0] || window.PHARMA40_USER.fullName;
    record["Checked By"] = registryValues("Checked by")[0] || window.PHARMA40_USER.fullName;
    return record;
}

function generateUniqueTracker() {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    const existing = documentState.documents.map(row => String(row["Routing Tracker #"] || "").trim().toUpperCase());
    let tracker = "";
    let attempts = 0;
    do {
        tracker = "";
        for (let i = 0; i < 4; i++) tracker += chars.charAt(Math.floor(Math.random() * chars.length));
        attempts++;
        if (attempts > 1000) throw new Error("Unable to generate a unique tracker number.");
    } while (existing.includes(tracker));
    return tracker;
}

function registryValues(type) {
    return registryEntries(type).filter(entry => entry.active !== false).map(entry => entry.value);
}

function registryEntries(type) {
    return normalizeRegistry(documentState.registries[type] || []);
}

function normalizeRegistry(values) {
    return values
        .map(item => typeof item === "string"
            ? { value: item, active: true, email: "" }
            : { value: item.value, active: item.active !== false, email: item.email || item["Email Address"] || "" })
        .filter(item => item.value);
}

function loadRegistries() {
    try {
        const saved = JSON.parse(localStorage.getItem("pharma40-vrms-registries"));
        if (saved) {
            Object.keys(REGISTRY_MAP).forEach(type => saved[type] = mergeRegistrySeeds(saved[type], REGISTRY_MAP[type]));
            return saved;
        }
    } catch {
        // Use seed data below.
    }
    return Object.fromEntries(Object.entries(REGISTRY_MAP).map(([type, values]) => [type, values.map(value => ({ value, active: true }))]));
}

function mergeRegistrySeeds(currentValues, seedValues) {
    const entries = normalizeRegistry(currentValues || []);
    seedValues.forEach(value => {
        if (!entries.some(entry => same(entry.value, value))) {
            entries.push({ value, active: true });
        }
    });
    return entries;
}

function loadDocuments() {
    try {
        const version = localStorage.getItem("pharma40-vrms-version");
        const saved = JSON.parse(localStorage.getItem("pharma40-vrms-documents"));
        if (version === STORE_VERSION && Array.isArray(saved)) return saved;
    } catch {
        // Use seed data below.
    }
    return seedDocuments();
}

function loadAudit() {
    try {
        const version = localStorage.getItem("pharma40-vrms-version");
        const saved = JSON.parse(localStorage.getItem("pharma40-vrms-audit-trail"));
        if (version === STORE_VERSION && Array.isArray(saved)) return saved;
    } catch {
        // Use seed data below.
    }
    return seedAudit();
}

function loadNotifications() {
    try {
        const saved = JSON.parse(localStorage.getItem("pharma40-notifications"));
        if (Array.isArray(saved)) return saved;
    } catch {
        // Start with an empty notification center.
    }
    return [];
}

function saveNotifications() {
    localStorage.setItem("pharma40-notifications", JSON.stringify(documentState.notifications.slice(0, 30)));
}

function pushNotification(title, message, type = "info", url = "", shouldRender = true) {
    documentState.notifications = [{
        id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
        title,
        message,
        type,
        url,
        read: false,
        time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    }, ...documentState.notifications].slice(0, 30);
    saveNotifications();
    if (shouldRender) renderDocuments();
}

function persistAll() {
    localStorage.setItem("pharma40-vrms-version", STORE_VERSION);
    localStorage.setItem("pharma40-vrms-documents", JSON.stringify(documentState.documents));
    localStorage.setItem("pharma40-vrms-registries", JSON.stringify(documentState.registries));
    localStorage.setItem("pharma40-vrms-audit-trail", JSON.stringify(documentState.audit));
}

function seedDocuments() {
    const seed = String.raw`API8	VMP-MM-11-000-008E-1	Betadine 7.5% Feminine Wash (BFW)	Process	NA	Sent	Ernz	NA	2026-05-14	Endorsement	26BFW-19	iNova Pharmaceuticals Philippines	TOP	CML	2026-04-22	SBA	2026-05-22	2026-05-15	Enz for implementation	2026-05-02	5/15/2026 7:38:43	Unknown user
D9RO	VMP-MM-02-000-075R-12	Clusivol Syrup	Process	NA	Cancelled	Isaiah		2026-04-22	Report	2025CSY-1, 2025CSY-2, 2025CSY-3	Haleon	LPM	ADF	2026-04-22	CML	2026-04-22	2026-09-30	Returned due to ongoing investigation as per Ma'am Fong and Ma'am Nadia, retuned 22 April 2026	5/2/2026 19:36:49	5/2/2026 19:36:49	carlolidres@gmail.com
B7H7	VMP-MM-00-000-076P-4	Elica 1mg per g Cream (EAM)	Process		Sent	Rev		2026-05-11	Protocol		Bayer Philippines, Inc. – Pharma Division	CO	ADF	2026-04-27	CML	2026-04-27	2026-05-08	For sending to client	2026-05-02	5/14/2026 6:24:47	Unknown user
L7XO	VMP-MM-01-000-289P	Calci-aid	Process		Sent	Rev		2026-05-07	Protocol		Bayer Philippines, Inc. – Pharma Division	SG	ADF	2026-04-27	LAL	2026-04-27	2026-05-08	Sent to Rev for client approval 05/07/2026	2026-05-02	5/7/2026 13:26:02	Unknown user
X4Q9	VMP-MM-01-000-185R-3	Ponstan 250mg Capsule (PTNP)	Process	NA	Sent	Icel		28 Apr 2026	Charac. Report	25PTNP1T1,25PTNP1T2,25PTNP1T3	Pfizer Inc.	DPM	NIV	6 Apr 2026	SBA	6 Apr 2026	2026-05-30		5/2/2026 19:45:00	5/2/2026 19:45:00	carlolidres@gmail.com
K2L7	VMP-MM-01-000-270P-2	Aspirin 80mg Enteric Coated Tablet (ASEC)	Process	NA	Routing	Jon		7 May 2026	Ver. Protocol	NA	Interphil Laboratories Inc.	DPM	ADF	13 Apr 2026	SBA	13 Apr 2026	2026-05-30	corrected, inserted the RnD coating pan in the protocol	2026-05-02	5/7/2026 7:42:41	Unknown user
M8ZT	VMP-MM-01-000-195P-8	Cetirizine HCl 10 mg Film-Coated Tablet (CTZA)	Process	NA	In EDMS	Isaiah		8 May 2026	Ver. Protocol	NA	Interphil Laboratories Inc.	DPM	ADF	17 Apr 2026	CML	17 Apr 2026	2026-05-30		2026-05-02	5/8/2026 15:27:55	Unknown user
P9WA	VMP-MM-01-000-151P-5	Ciprofloxacin 500mg Film-Coated Tablet (CIRT)	Process	NA	In EDMS	Isaiah		8 May 2026	Ver. Protocol	NA	Interphil Laboratories Inc.	DPM	ADF	17 Apr 2026	CML	17 Apr 2026	2026-05-30		2026-05-02	5/8/2026 15:26:14	Unknown user
R3VX	VMP-MM-01-000-031E-6	Tempra 325 mg Tablet (TPTL)	Process	NA	In EDMS	Isaiah		11 May 2026	Verif. Endorsement Report	2025TPTL-181	NA	DPM	NIV	24 Mar 2026	SBA	24 Mar 2026	2026-05-30		2026-05-02	5/11/2026 16:35:42	Unknown user
T7CN	VMP-MM-01-000-193E-1	Mosegor Vita Capsule (MVC)	Process	NA	Routing	Ernz		21 Apr 2026	Charac. Endorsement	2024MVC-9	NA	DPM	ADF	18 Mar 2026	CML	18 Mar 2026	2026-05-30	MVC - internal routing of batch docs (04 May 2026)	2026-05-02	5/5/2026 8:44:20	Unknown user
Z5HJ	VMP-MM-01-000-013E-6	Tempra Forte 500 mg Tablet (TPFT)	Process	NA	Routing	Othy		15 May 2026	Ver. Endorsement	2025TPFT-511	NA	DPM	NIV	26 Feb 2026	SBA	26 Feb 2026	2026-05-30		2026-05-02	5/15/2026 9:04:21	Unknown user
Q8MF	VMP-MM-11-000-008E	Betadine 7.5% Feminine Wash (BFW)	Process	NA	Sent	Ernz		26 Feb 2026	Ver. Endorsement	25BFW-39A	NA	TOP	NIV	26 Feb 2026	SBA	26 Feb 2026	2026-05-30		2026-05-02	5/15/2026 7:42:38	Unknown user
U2KP	VMP-MM-01-000-288E-1	Rogin-E Softgel Capsule (REC)	Process	NA	Routing	Ernz		8 Apr 2026	Endorsement	33841-01IL, 34140-01IL, and 34158-01IL	NA	DPP	NIV	26 Feb 2026	SBA	26 Feb 2026	2026-05-30		5/2/2026 19:45:00	5/2/2026 19:45:00	carlolidres@gmail.com
N6RD	VMP-MM-02-000-142P-3	Valbazen 11.25% Suspension (VEN) 	Process	N/A	Sent	Client		11 May 2026	Val. Protocol	N/A	Zoetis Philippines, Inc.	LPM	ADF	30 Apr 2026	LAL	30 Apr 2026	2026-05-05	sent to client c/o Carl 11 May 2026	2026-05-02	5/11/2026 9:28:25	Unknown user
Y4BG	VMP-FA-04-018-020/26	Manager's Room Annual Thermal Mapping	Non-Process	N/A	Routing	Lenie		15 May 2026	USV Endorsement			QC Plant1	NIV	24 Mar 2026	SBA	24 Mar 2026	2026-05-30		2026-05-02	5/15/2026 8:16:01	Unknown user
H9SX	VMP-EQ-01-000-043R-3	Manesty D3B Tabletting Machine	Non-Process	IL-0039	Routing	Fong		16 Apr 2026	Report			Dry	NIV	24 Jul 2024	SBA	25 Jul 2024	2026-05-30		5/2/2026 19:45:00	5/2/2026 19:45:00	carlolidres@gmail.com
C7LU	VMP-FA-04-018-001/26	Controlled Room Thermal Mapping	Non-Process	NA	Routing	Bing		15 May 2026	USV Endorsement			WH Plant 1	RDM	22 Apr 2026	SBA	23 Apr 2026	2026-05-30		2026-05-02	5/15/2026 12:50:07	Unknown user
W3EZ	VMP-FA-04-018-008/26	Raw Materials for weighing and Raw Materials Staging Area Thermal Mapping	Non-Process	NA	Routing	Venie		15 May 2026	USV Endorsement			Disp	RDM	4 Apr 2026	SBA	6 Apr 2026	2026-05-30		2026-05-02	5/15/2026 12:51:29	Unknown user
F8TJ	VMP-ST Rev No. 23	Site Validation Master Plan	Others	NA	In EDMS	Isaiah		2026-05-07	Others	NA	NA	Other	CML	2026-03-30	SBA	2026-03-30	2026-05-30	For Scanning to eDMS	2026-05-02	5/7/2026	Unknown user
J5NA	VMP-MM-02-000-117P-11	Robitussin DM 15 mg/100 mg per 5 mL Syrup (RDMS)	Process	N/A	Sent	Suzette		11 May 2026	Ver. Protocol	N/A	Haleon	LPM	ADF	30 Apr 2026	CML	30 Apr 2026	2026-05-30		2026-05-02	5/14/2026 6:24:04	Unknown user
6VOD	VMP-MM-01-000-301P.1	Rosuvastatin 20mg FC Tablet	Process	NA	In EDMS	Isaiah		2026-05-04	Val. Protocol	NA	Interphil Laboratories Inc.	DPM	ADF	2026-04-17	CML	2026-05-17		Done	5/4/2026 7:28:00	5/4/2026 7:28:00	Unknown user
4LVO	APR-2026-030	Benadryl AH 25mg Capsule	APR	NA	In EDMS	Timi		2026-05-04	APR		JNTL Consumer Health (Philippines), Inc.		FBP & LAL	2026-04-30	CML	2026-04-30	2026-05-04	c/o Timi for safekeeping	2026-05-04	5/7/2026 11:04:46	Unknown user
UHHT	APR-2026-003	Omnicef Powder for Oral Suspension	APR		In EDMS	Timi		2026-05-05	APR		Pfizer Inc.		FBP	2026-05-04	CML	2026-05-04		c/o Timi for Safekeeping	2026-05-04	5/7/2026 11:07:43	Unknown user
1I2F	VMP-MM-02-000-103P-9	Cetirizine Hydrochloride 5mg/5mL Syrup (AXLS)	Process		In EDMS	Isaiah		2026-05-14	Ver. Protocol	N/A	NA	LPP	ADF	2026-05-04	CML	2026-05-04	2026-05-18		2026-05-04	5/14/2026 6:20:46	Unknown user
W5L3	APR-2026-016	Ponstan SF 250 Capsule	APR	NA	In EDMS	Timi		2026-05-05	APR	NA	Pfizer Inc.	DPM	LAL	2026-04-30	CML	2026-04-30	2026-05-08	forwarded to Timi for safekeeping	2026-05-04	5/7/2026 11:09:00	Unknown user
HL6D	APR-2025-115	Iselpin 1g Tablet	APR		Sent	Client		2026-05-07	APR		Pfizer Inc.		FBP	2026-05-05	CML	2026-05-05		c/o Timi for safekeeping	2026-05-05	5/7/2026 9:52:30	Unknown user
BQKF	VMP-MM-01-000-195R-7	Cetirizine HCl 10 mg Film-Coated Tablet (CTZA) 	Process		Routing	Fong		2026-05-14	Ver. Report	2026CTZA-4	NA	DPM	ADF	2026-05-05	CML	2026-05-05			2026-05-05	5/14/2026 16:48:27	Unknown user
J8PF	VMP-MM-01-000-138R-6	Amlodipine Besilate 10mg Tablet (ABES)	Process		Routing	Fong		2026-05-14	Ver. Report	2025ABES-4		DPM	CML	2026-05-07	SBA	2026-05-07			2026-05-07	5/14/2026 16:49:02	Unknown user
VAP0	VMP-MM-02-000-092P-6	Combantrin 125 mg/5 mL Suspension (COMB)	Process		In EDMS	Isaiah		2026-05-14	Ver. Protocol	NA	JNTL Consumer Health (Philippines), Inc.	LPP	ADF	2026-05-07	CML	2026-05-07	2026-05-28		2026-05-07	5/14/2026 6:21:37	Unknown user
6KXH	VMP-MM-01-000-199R-1	Isordil Oral 10mg Tablet (ILT10) 	Process	NA	Sent	Client		2026-05-07	Char. Report	2025ILT10-1	Pfizer Inc.	DPM	NIV	2025-05-04	CML	2025-05-04	2026-05-15	Follow-up email sent to Kumar 07May2026 c/o Carl cc: Icel, Anissa, and Angela	2026-05-07	5/7/2026 15:45:44	Unknown user
7BGE	VMP-MM-01-000-189R-6	Ponstan SF 500mg Capsule (PTNP)	Process		Routing	Fong			Char. Report	25PNSC-15T, 25PNSC16T, and 25PNSC16T	Pfizer Inc.	DPM	CML	2026-05-07	SBA	2026-05-07			2026-05-07	5/14/2026 16:47:41	Unknown user
94YK	VMP-MM-01-000-286I-1 (1)	Dilzem 60mg Tablet (DLZ)	Process	NA	Sent	Client		2026-05-07	Interim Report	2025DLZ-1, 2025DLZ-2	Pfizer Inc.	DPM	NIV	2025-09-05	CML	2025-09-05	2026-05-15	Follow-up email sent to Kumar 07May2026 c/o Carl cc: Icel, Anissa, and Angela	2026-05-07	5/7/2026 15:46:08	Unknown user
D0E4	VMP-MM-01-000-285I-1 (1)	Dilzem 30mg Tablet (DZM)	Process	NA	Sent	Client		2026-05-07	Interim Report	2025DZM-1, 2025DZM-2	Pfizer Inc.	DPM	NIV	2025-09-03	CML	2025-09-03		Follow-up email sent to Kumar 07May2026 c/o Carl cc: Icel, Anissa, and Angela	2026-05-07	5/7/2026 15:45:19	Unknown user
6XDK	VMP-MM-02-000-103-6.1	Cetirizine Hydrochloride  5mg/5mL Syrup	Process	NA	For Scanning	Isaiah		2026-05-14	Ver. Report		NA	LPP	CML	2026-05-08			2026-04-08		2026-05-08	5/14/2026 15:09:30	Unknown user
PIU9	ER-SYS-04-018-002/26	General Warehouse (RM and PM-FG Area) Thermal Mapping	Non-process		Routing	Bing		2026-05-15	Endorsement			WH Plant 1	RDM	2026-04-30	CML	2026-04-30	2026-05-30		2026-05-11	5/15/2026 12:52:32	Unknown user
RZU2	SMF-005 Rev. 15	 Site Master File Drug Manufacturer 	Others		Routing	Marvin		2026-05-12	Report				CML	2026-04-28					2026-05-12	5/14/2026 14:19:03	Unknown user
H79K	VMP-MM-01-000-179P-4	Clopidogrel 75 mg Film-Coated Tablet (CLPD)	Process		Routing	Kitel		2026-05-12	Ver. Protocol	N/A	NA	DPM	ADF	2026-05-12	CML	2026-05-12	2026-06-01		2026-05-12	5/15/2026 10:39:38	Unknown user
Z961	VMP-MM-00-000-051P-9	Hydrocortisone 10 mg/g (1%) Emollient Cream (INFC)	Process		Routing	Aiza		2026-05-12	Val. Protocol	N/A	NA	CO	ADF	2026-05-12	CML	2026-05-12			2026-05-12	5/15/2026 10:39:02	Unknown user
EIN9	ER-SYS-04-018-003/26	Small Quantity Pakaging Materials Storage Area Thermal Mapping	Non-process		Routing	Steve			USV Endorsement			WH Plant 1	RDM	2026-05-12	CML	2026-05-12			2026-05-12	5/12/2026 13:26:07	Unknown user
CGBX	ER-SYS-04-018-004/26	General Warehouse (FD-FC Area) Thermal Mapping	Non-process		Routing	Steve			USV Endorsement			WH Plant 1	RDM	2026-05-12	CML	2026-05-12			5/12/2026 13:25:40	5/12/2026 13:25:40	Unknown user
OXHF	VMP-MM-00-000-085R.3	Daktarin 20mg/g Oral Gel (Reformulated) (DKGC)	Process		Routing	Fong		2026-05-14	Char. Report	2026DKGC-2	JNTL Consumer Health (Philippines), Inc.	CO	ADF	2026-05-13	CML	2026-05-13	2026-06-01		2026-05-13	5/14/2026 17:29:17	Unknown user
EMRA	N/A	Supraneuron Film-Coated Tablet	Process		Routing	Karen		2026-05-13	Others	2026SPRN-1	Bayer Philippines, Inc. – Pharma Division	DPM	ADF & CML	2026-05-13	CML	2026-05-13	2026-05-15	Investigation Report	5/13/2026 14:43:54	5/13/2026 14:43:54	Unknown user
M3VB	CMP-CM-01-000-067E	Cleaning Parameters (DPM)	Non-process		Routing	Ron			Endorsement			DPM	LAL	2026-05-14	SBA	2026-05-14			2026-05-13	5/15/2026 10:45:22	Unknown user
BFXZ	VMP-CM-01-000-067E-1	Cleaning Parameters (DPP)	Non-process		Routing	Ron			Endorsement			DPP	LAL	2026-05-14	SBA	2026-05-14			2026-05-13	5/15/2026 10:47:37	Unknown user
N41J	VMP-MM-11-000-002R-1	Betadine 7.5% Skin Cleanser (BSC)	Process		Sent	Client		2026-05-15	Ver. Report	26BSC-31	iNova Pharmaceuticals Philippines	TOP	ADF & CML	2026-05-14	SBA	2026-05-14		Hardcopy last with sir Jon	2026-05-14	5/15/2026 9:02:55	Unknown user
31TJ	VMP-MM-01-000-264P-3	Imodium 2mg Capsule (IMC)	Process		Routing	Cara			Ver. Protocol		JNTL Consumer Health (Philippines), Inc.	DPM	ADF & CML	2026-05-14	SBA	2026-05-14			2026-05-14	5/14/2026 10:37:54	Unknown user
1RZH	VMP-MM-01-000-300P-4	Supraneuron Film-Coated Tablet (SPRN)	Process		Sent	Iya		2026-05-14	Char. Protocol	NA	Bayer Philippines, Inc. – Consumer Care Division	DPM	ADF	2026-05-14	CML	2026-05-14	2026-05-22	sent to Iya for client review, draft sent by Angela	2026-05-14	5/14/2026 10:24:46	Unknown user
QWNN	VMP-MM-01-000-135R-5.1	Calsan 500mg Chewable Tablet (CAL)	Process	NA	Routing	Nadia		2026-05-14	Val. Report	2024CAL-5, 2024CAL-6, 2024CAL-7	Sandoz Philippines Corp.	DPM	CML	2026-05-14	SBA	2026-05-14	2026-05-29		2026-05-14	5/14/2026 11:13:02	Unknown user
J57D	APR-2026-035	Dilantin 30mg / 5mL Pediatric Suspension (DIPS)	APR		Sent	Client		2026-05-15			Viatris, Inc.		LAL	2026-05-14	SBA	2026-05-14		for approval Nadean Knight	2026-05-14	5/15/2026 13:18:08	Unknown user
8KRA	VMP-MM-02-000-106P-6	Dilantin 125mg/5mL Adult Suspension (DIAS)	Process		Routing	Cara		2026-05-14	Ver. Protocol	N/A	NA	LPP	ADF	2026-05-14	CML	2026-05-14	2026-05-29		2026-05-14	5/14/2026 13:11:27	Unknown user
NTEQ	VMP-MM-11-000-006R-1	Betadine 7.5% Skin Cleanser / Scrub (Reformulated) (BSCS) 	Process		Routing	Steve		2026-05-14	Char. Report	 2026BSCS-1, 2026BSCS-2, 2026BSCS-3	iNova Pharmaceuticals (Singapore) Pte. Ltd.	TOP	ADF	2026-05-14	CML	2026-05-14	2026-05-29		5/14/2026 12:38:08	5/14/2026 12:38:08	Unknown user
GJXQ	APR-2026-034	Dilantin 125mg / 5mL Adult Suspension			Routing	Fong					Viatris, Inc.		LAL	2026-05-14	CML	2026-05-14			5/14/2026 13:24:22	5/14/2026 13:24:22	Unknown user
UFG8	APR-2023-119	Iselpin Tablet (INT)	APR		Routing	Fong		2026-05-14			Pfizer Inc.	DPM	LAL	2026-05-14	CML	2026-05-14			2026-05-14	5/14/2026 13:34:35	Unknown user
CNSU	Not Applicable	Rosuvastatin 20mg FC Tablet	Process		Routing	Fong			Investigation Report				ADF	2026-05-14	CML	2026-05-14			5/14/2026 13:34:43	5/14/2026 13:34:43	Unknown user
LRRH	APR-2024-128	Iselpin Tablet	APR		Routing	Fong		2026-05-14	Others		Pfizer Inc.	Other	FBP & CML	2026-05-14	CML	2026-05-14			2026-05-14	5/14/2026 13:39:50	Unknown user
0KGF	APR-2025-098	Dalacin C 75 mg/5 mL Granules For Oral Solution	APR		Routing	Fong		2026-05-14			Pfizer Inc.		FBP & CML	2026-05-14					5/14/2026 13:42:20	5/14/2026 13:42:20	Unknown user`;

    return seed.split("\n").filter(Boolean).map(line => {
        const cells = line.split("\t");
        const record = {};
        DOCUMENT_HEADERS.forEach((header, index) => record[header] = normalizeCell(cells[index]));
        return record;
    });
}

function normalizeCell(value) {
    const text = String(value ?? "").trim();
    if (text === "QC Plant1") return "QC Plant 1";
    if (text === "Disp") return "Dispensing";
    return text;
}

function seedDoc(tracker, tracer, equipment, category, ilTag, status, sentTo, email, dateSent, reportProtocol, batchNo, client, department, preparedBy, datePrepared, checkedBy, dateChecked, targetDate, remarks, createdAt, updatedAt) {
    return {
        "Routing Tracker #": tracker,
        "Doc Tracer #": tracer,
        "Equipment/Product": equipment,
        "Category": category,
        "IL-Tag": ilTag,
        "Status": status,
        "Sent/Routing To": sentTo,
        "Email": email,
        "Date Sent": dateSent,
        "Report/Protocol": reportProtocol,
        "Batch No.": batchNo,
        "Client Name": client,
        "Department": department,
        "Prepared By": preparedBy,
        "Date Prepared": datePrepared,
        "Checked By": checkedBy,
        "Date Checked": dateChecked,
        "Target Completion Date": targetDate,
        "Remarks": remarks,
        "Created At": createdAt,
        "Updated At": updatedAt,
        "Updated By": preparedBy
    };
}

function seedAudit() {
    return [
        auditRow("2026-05-15", "Unknown user", "Updated document", "K2L7", "VMP-MM-01-000-270P-2", "{\"Sent/Routing To\":{\"from\":\"Fong\",\"to\":\"Jon\"}}"),
        auditRow("2026-05-15", "Unknown user", "Added registry value", "", "", "Sent / Routing: Lenie"),
        auditRow("2026-05-14", "Carlo Lidres", "Created document", "API8", "VMP-MM-11-000-008E-1", "New document routing record created.")
    ];
}

function auditRow(timestamp, user, action, tracker, tracer, details) {
    return {
        Timestamp: timestamp,
        User: user,
        Action: action,
        "Routing Tracker #": tracker,
        "Doc Tracer #": tracer,
        Details: details
    };
}

function logAudit(action, tracker, tracer, details) {
    documentState.audit.unshift(auditRow(
        formatDateTimeValue(new Date()),
        window.PHARMA40_USER.email || window.PHARMA40_USER.fullName || "Unknown user",
        action,
        tracker,
        tracer,
        details
    ));
}

function diffRecord(before, after) {
    const changes = {};
    DOCUMENT_HEADERS.forEach(header => {
        if (String(before[header] || "") !== String(after[header] || "")) {
            changes[header] = { from: before[header] || "", to: after[header] || "" };
        }
    });
    return changes;
}

function exportCsv() {
    const rows = documentState.activePage === "database" ? filteredDatabaseRows() : documentState.documents;
    const csvRows = [DOCUMENT_HEADERS].concat(rows.map(row => DOCUMENT_HEADERS.map(header => row[header] || "")));
    const csv = csvRows.map(row => row.map(cell => `"${String(cell).replaceAll('"', '""')}"`).join(",")).join("\n");
    const link = document.createElement("a");
    link.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    link.download = "vrms-database.csv";
    link.click();
    URL.revokeObjectURL(link.href);
    showToast("CSV exported.");
}

function showToast(message) {
    pushNotification("VRMS update", message, "info");
}

function statusPill(value) {
    const className = statusClass(value);
    return `<span class="status-pill status-${className}">${escapeHtml(value || "Blank")}</span>`;
}

function statusClass(value) {
    return String(value || "Blank").replace(/\s+/g, "-").toLowerCase();
}

function daysBetween(start, end) {
    if (!start) return -1;
    const startDate = new Date(start);
    if (Number.isNaN(startDate.getTime())) return -1;
    return Math.floor((new Date(end) - startDate) / 86400000);
}

function same(left, right) {
    return String(left || "").trim().toLowerCase() === String(right || "").trim().toLowerCase();
}

function isValidEmail(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || "").trim());
}

function formatDateValue(value) {
    return new Date(value).toISOString().slice(0, 10);
}

function formatDateTimeValue(value) {
    return new Date(value).toISOString().slice(0, 10);
}

function cssEscape(value) {
    return String(value).replaceAll("\\", "\\\\").replaceAll('"', '\\"');
}

function hydrateDocumentIcons() {
    if (window.lucide?.createIcons) {
        window.lucide.createIcons({ attrs: { width: 17, height: 17, "stroke-width": 2 } });
    }
}

function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function escapeAttribute(value) {
    return escapeHtml(value).replaceAll("\n", "&#10;");
}
