(function () {
    const storageKey = "pharma40-theme";
    const allowed = new Set(["light", "dark", "night"]);

    function normalize(value) {
        const raw = String(value || "").trim().toLowerCase();
        if (allowed.has(raw)) return raw;
        return "light";
    }

    function apply(theme) {
        const next = normalize(theme);
        document.documentElement.dataset.theme = next;
        if (document.body) document.body.dataset.theme = next;
        localStorage.setItem(storageKey, next);
        return next;
    }

    function current() {
        return normalize(localStorage.getItem(storageKey));
    }

    window.PharmaTheme = { storageKey, current, apply, normalize, allowed: Array.from(allowed) };
    apply(current());
})();
