using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Pharma40.Services;

namespace Pharma40.Pages;

[IgnoreAntiforgeryToken]
public class AuthModel(AuthService authService) : PageModel
{
    public IActionResult OnGet()
    {
        return HttpContext.Session.GetInt32("UserId") is null
            ? Page()
            : RedirectToPage("/Dashboard");
    }

    public IActionResult OnPostLogin(string email, string password)
    {
        var result = authService.Login(email ?? "", password ?? "");
        if (!result.Success || result.User is null)
        {
            return new JsonResult(new { success = false, result.Message });
        }

        HttpContext.Session.SetInt32("UserId", result.User.Id);
        HttpContext.Session.SetString("FullName", result.User.FullName);
        HttpContext.Session.SetString("Email", result.User.Email);
        HttpContext.Session.SetString("Role", result.User.Role);

        return new JsonResult(new { success = true, result.Message, redirectUrl = Url.Page("/Dashboard") });
    }

    public IActionResult OnPostRegister(string fullName, string email, string password)
    {
        var result = authService.Register(fullName ?? "", email ?? "", password ?? "");
        return new JsonResult(new { success = result.Success, result.Message });
    }

    public IActionResult OnPostSendCode(string email)
    {
        var result = authService.SendResetCode(email ?? "");
        return new JsonResult(new { success = result.Success, result.Message, code = result.Code });
    }

    public IActionResult OnPostResetPassword(string email, string code, string newPassword)
    {
        var result = authService.ResetPassword(email ?? "", code ?? "", newPassword ?? "");
        return new JsonResult(new { success = result.Success, result.Message });
    }
}
