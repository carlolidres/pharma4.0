using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Pharma40.Models;
using Pharma40.Services;

namespace Pharma40.Pages;

public class DashboardModel(AuthService authService) : PageModel
{
    public User? CurrentUser { get; private set; }
    public string Initials { get; private set; } = "U";

    public IActionResult OnGet()
    {
        var userId = HttpContext.Session.GetInt32("UserId");
        if (userId is null)
        {
            return RedirectToPage("/Auth");
        }

        CurrentUser = authService.GetUser(userId.Value);
        if (CurrentUser is null)
        {
            HttpContext.Session.Clear();
            return RedirectToPage("/Auth");
        }

        Initials = BuildInitials(CurrentUser.FullName);
        return Page();
    }

    private static string BuildInitials(string fullName)
    {
        var parts = fullName.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length == 0)
        {
            return "U";
        }

        return string.Concat(parts.Take(2).Select(part => char.ToUpperInvariant(part[0])));
    }
}
