using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Pharma40.Services;

namespace Pharma40.Pages.Api;

[IgnoreAntiforgeryToken]
public class TcodesModel(TCodeService tCodeService, AuthService authService) : PageModel
{
    public IActionResult OnGetList()
    {
        if (!IsAuthenticated())
        {
            return new JsonResult(new { success = false, message = "Session expired." }) { StatusCode = StatusCodes.Status401Unauthorized };
        }

        return new JsonResult(new { success = true, items = tCodeService.GetAll() });
    }

    public IActionResult OnGetLaunch(string tcode)
    {
        if (!IsAuthenticated())
        {
            return new JsonResult(new { success = false, message = "Session expired." }) { StatusCode = StatusCodes.Status401Unauthorized };
        }

        var item = tCodeService.Find(tcode ?? "");
        return item is null
            ? new JsonResult(new { success = false, message = "Transaction code not found." })
            : new JsonResult(new { success = true, item });
    }

    private bool IsAuthenticated()
    {
        var userId = HttpContext.Session.GetInt32("UserId");
        return userId is not null && authService.GetUser(userId.Value) is not null;
    }
}
