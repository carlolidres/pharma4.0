﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Pharma40.Pages;

public class PrivacyModel : PageModel
{
    public void OnGet()
    {
    }
}

