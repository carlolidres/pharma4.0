using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Pharma40.Services;

namespace Pharma40.Pages;

public class IndexModel(AuthService authService) : PageModel
{
    public IActionResult OnGet()
    {
        var userId = HttpContext.Session.GetInt32("UserId");
        return userId is not null && authService.GetUser(userId.Value) is not null
            ? RedirectToPage("/Dashboard")
            : RedirectToPage("/Auth");
    }
}
