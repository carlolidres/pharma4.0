// Reserved for chart widgets.
