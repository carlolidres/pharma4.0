namespace Pharma40.Models;

public sealed class TCode
{
    public int Id { get; set; }
    public string Code { get; set; } = "";
    public string ModuleName { get; set; } = "";
    public string Description { get; set; } = "";
    public string FunctionDetails { get; set; } = "";
    public string PageUrl { get; set; } = "#";
    public string Status { get; set; } = "Active";
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
