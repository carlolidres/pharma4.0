namespace Pharma40.Models;

public sealed class AppData
{
    public int NextUserId { get; set; } = 1;
    public List<User> Users { get; set; } = [];
    public List<TCode> TCodes { get; set; } = [];
}
