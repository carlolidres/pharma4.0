# Document Management and Routing System

The active VRMS module is served through the authenticated Razor Page `/Documents`.

This folder records the module boundary for the Pharma4.0 module tree and keeps the implementation notes close to the Documents module. Runtime UI assets live in `wwwroot/css/documents.css` and `wwwroot/js/documents.js` so they are served by the existing ASP.NET static file pipeline.

Reference sources used:

- `templates/vrms---template`: initial VRMS fields, registries, sample records, audit log behavior, and routing concepts.
- `templates/TailWind Templates`: compact dashboard/table/form visual density.
- `e-Dokyumento-master`: document workflow and routing concept reference.

Transaction code:

- `VRMS`
- Target route: `/Documents`
